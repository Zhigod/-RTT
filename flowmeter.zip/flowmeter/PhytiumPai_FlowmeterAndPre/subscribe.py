import paho.mqtt.client as mqtt
import json
import math
import time
import csv
import os
import threading


def parse_coordinate(coord_str):
    try:
        direction = coord_str[-1]
        value_str = coord_str[:-1]
        if direction in ['N', 'S']:
            degrees = int(value_str[:2])
            minutes = float(value_str[2:])
        elif direction in ['E', 'W']:
            degrees = int(value_str[:3])
            minutes = float(value_str[3:])
        else:
            print(f"未知的方向标识: {direction}")
            return None
        decimal = degrees + minutes / 60.0
        if direction in ['S', 'W']:
            decimal = -decimal
        return decimal
    except Exception as e:
        print(f"解析坐标 '{coord_str}' 错误: {e}")
        return None


class MQTTHandler:
    def __init__(self):
        self.order_of_m = 3
        self.multiple = 3
        self.csv_file = "mqtt_data.csv"
        self.devices = {
            "STM32H71": {
                'current': {'latitude': None, 'longitude': None, 'corr_max_lags_ms': None},
                'last_recorded': {'latitude': None, 'longitude': None, 'corr_max_lags_ms': None},
                'zero_corr_recorded': False
            },
            "STM32H72": {
                'current': {'latitude': None, 'longitude': None, 'corr_max_lags_ms': None},
                'last_recorded': {'latitude': None, 'longitude': None, 'corr_max_lags_ms': None},
                'zero_corr_recorded': False
            }
        }
        self.init_csv()
        self.client = self._create_client()

    def _create_client(self):
        client_id = 'k1h20s5zVGz.MATLAB|securemode=2,signmethod=hmacsha256,timestamp=1743514388351|'
        username = 'MATLAB&k1h20s5zVGz'
        password = 'b4b2c5ddcab7e88a9824b7b973bdcfb8a4b2697f7689aa2f96d013a6732e1f75'
        client = mqtt.Client(client_id=client_id, callback_api_version=mqtt.CallbackAPIVersion.VERSION2)
        client.username_pw_set(username, password)
        client.on_connect = self.on_connect
        client.on_message = self.on_message
        client.reconnect_delay_set(min_delay=1, max_delay=120)
        return client

    def init_csv(self):
        header = ["time", "latitude_1", "longitude_1", "corr_max_lags_ms_1",
                  "latitude_2", "longitude_2", "corr_max_lags_ms_2", "distance", "flow_speed"]
        if not os.path.exists(self.csv_file):
            with open(self.csv_file, "w", newline="") as f:
                writer = csv.writer(f)
                writer.writerow(header)

    def on_connect(self, client, userdata, flags, reason_code, properties):
        if reason_code == 0:
            print("连接成功")
            topic = "/sys/k1h20s5zVGz/MATLAB/thing/event/property/post"
            client.subscribe(topic, qos=1)
            print(f"已订阅主题: {topic}")
        else:
            print(f"连接失败，状态码: {reason_code}")

    def on_message(self, client, userdata, msg):
        try:
            payload = json.loads(msg.payload.decode())
            original_device = payload.get("deviceName")
            items = payload.get('items', {})
            print(f"收到来自 {original_device} 的数据")
            if original_device in ["STM32H71", "STM32H72"]:
                self._update_device_data(items, original_device)
        except Exception as e:
            print(f"处理消息异常: {e}")

    def _update_device_data(self, items, device_name):
        try:
            device = self.devices[device_name]
            current = device['current']
            latitude_str = items.get("latitude", {}).get("value", "")
            longitude_str = items.get("longitude", {}).get("value", "")
            corr_value = items.get("corr_max_lags_ms", {}).get("value", None)

            if latitude_str:
                current['latitude'] = parse_coordinate(latitude_str)
            if longitude_str:
                current['longitude'] = parse_coordinate(longitude_str)
            if corr_value is not None:
                current['corr_max_lags_ms'] = float(corr_value)

            print(f"更新 {device_name} 数据: {current}")
        except Exception as e:
            print(f"更新设备数据错误: {e}")

    def start(self):
        self.client.connect("iot-06z00g00rbaa0u6.mqtt.iothub.aliyuncs.com", 1883)
        self.client.loop_start()
        self.schedule_next_record()

    def schedule_next_record(self):
        now = time.time()
        next_time = ((int(now) // 10) + 1) * 10
        delay = next_time - now
        threading.Timer(delay, self.record_data).start()

    def record_data(self):
        try:
            adjusted_time = (int(time.time()) // 10) * 10
            record_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(adjusted_time))

            data1 = self._merge_device_data('STM32H71')
            data2 = self._merge_device_data('STM32H72')

            if not data1 or not data2:
                print("数据不全，跳过记录")
                return

            if not self._check_corr_zero('STM32H71', data1) or not self._check_corr_zero('STM32H72', data2):
                print("忽略重复的零值记录")
                return

            distance = self.calculate_distance(data1['latitude'], data1['longitude'], data2['latitude'],
                                               data2['longitude'])
            flow_speed = self.calculate_flow_speed(data1['corr_max_lags_ms'], data2['corr_max_lags_ms'], distance)

            with open(self.csv_file, "a", newline="") as f:
                writer = csv.writer(f)
                writer.writerow([
                    record_time,
                    data1['latitude'], data1['longitude'], data1['corr_max_lags_ms'],
                    data2['latitude'], data2['longitude'], data2['corr_max_lags_ms'],
                    distance, flow_speed
                ])
            print(f"记录时间: {record_time}, 距离: {distance:.4f}km, 流速: {flow_speed:.2f}m/s")

            self._update_last_recorded('STM32H71', data1)
            self._update_last_recorded('STM32H72', data2)

        except Exception as e:
            print(f"记录数据错误: {e}")
        finally:
            self.schedule_next_record()

    def _merge_device_data(self, device_name):
        device = self.devices[device_name]
        merged = {
            'latitude': device['current']['latitude'] or device['last_recorded']['latitude'],
            'longitude': device['current']['longitude'] or device['last_recorded']['longitude'],
            'corr_max_lags_ms': device['current']['corr_max_lags_ms'] or device['last_recorded']['corr_max_lags_ms']
        }
        if None in merged.values():
            print(f"{device_name} 数据不全")
            return None
        return merged

    def _check_corr_zero(self, device_name, data):
        device = self.devices[device_name]
        if data['corr_max_lags_ms'] == 0:
            if device['zero_corr_recorded']:
                return False
            device['zero_corr_recorded'] = True
        else:
            device['zero_corr_recorded'] = False
        return True

    def _update_last_recorded(self, device_name, data):
        device = self.devices[device_name]
        device['last_recorded'].update(data)
        device['current'].update({k: None for k in device['current']})

    def calculate_distance(self, lat1, lon1, lat2, lon2):
        if None in [lat1, lon1, lat2, lon2]:
            return 0.0
        R = 6371.0
        lat1 = math.radians(lat1)
        lon1 = math.radians(lon1)
        lat2 = math.radians(lat2)
        lon2 = math.radians(lon2)
        dlat = lat2 - lat1
        dlon = lon2 - lon1
        a = math.sin(dlat / 2) ** 2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon / 2) ** 2
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
        return R * c

    def calculate_flow_speed(self, corr1, corr2, distance):
        if corr1 == 0 or corr2 == 0 or distance == 0:
            return 0.0
        try:
            return abs((distance / 2) * (1 / corr1 - 1 / corr2) * 1000)
        except ZeroDivisionError:
            return 0.0


if __name__ == "__main__":
    handler = MQTTHandler()
    try:
        handler.start()
    except KeyboardInterrupt:
        print("程序终止")
        handler.client.disconnect()