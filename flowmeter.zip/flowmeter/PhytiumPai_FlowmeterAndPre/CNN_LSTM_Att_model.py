import torch
import torch.nn as nn
import torch.nn.functional as F

# QKV 自注意力机制
class QKVSelfAttention(nn.Module):
    def __init__(self, hidden_dim):
        super(QKVSelfAttention, self).__init__()
        self.query_projection = nn.Linear(hidden_dim, hidden_dim)
        self.key_projection = nn.Linear(hidden_dim, hidden_dim)
        self.value_projection = nn.Linear(hidden_dim, hidden_dim)

    def forward(self, encoder_outputs):
        Q = self.query_projection(encoder_outputs)
        K = self.key_projection(encoder_outputs)
        V = self.value_projection(encoder_outputs)

        attention_scores = torch.bmm(Q, K.transpose(1, 2))
        attention_weights = F.softmax(attention_scores, dim=-1)
        attention_output = torch.bmm(attention_weights, V)
        return attention_output, attention_weights

# 主模型结构：CNN + LSTM + QKV Self-Attention
class CNN_LSTM_Att(nn.Module):
    def __init__(self, input_size, hidden_size, output_size, kernel_size, num_layers=1):
        super(CNN_LSTM_Att, self).__init__()
        self.conv1 = nn.Conv1d(input_size, hidden_size, kernel_size)
        self.relu1 = nn.ReLU()
        self.pool = nn.MaxPool1d(kernel_size=2)
        self.lstm = nn.LSTM(hidden_size, hidden_size, num_layers, batch_first=True)
        self.fc = nn.Linear(hidden_size, output_size)
        self.qkv_attention = QKVSelfAttention(hidden_size)

    def forward(self, x):
        x = self.conv1(x)
        x = self.relu1(x)
        x = self.pool(x)
        x = x.permute(0, 2, 1)
        out, _ = self.lstm(x)
        attention_output, _ = self.qkv_attention(out)
        last_output = attention_output[:, -1, :]
        output = self.fc(last_output)
        return output