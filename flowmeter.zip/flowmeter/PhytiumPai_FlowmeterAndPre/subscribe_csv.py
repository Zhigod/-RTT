import paho.mqtt.client as mqtt
import json
import math
import time
import csv
import os

def parse_coordinate(coord_str):
    # 原有解析函数保持不变
    try:
        direction = coord_str[-1]
        value_str = coord_str[:-1]
        if direction in ['N', 'S']:
            degrees = int(value_str[:2])
            minutes = float(value_str[2:])
        elif direction in ['E', 'W']:
            degrees = int(value_str[:3])
            minutes = float(value_str[3:])
        else:
            print(f"未知的方向标识: {direction}")
            return None
        decimal = degrees + minutes / 60.0
        if direction in ['S', 'W']:
            decimal = -decimal
        return decimal
    except Exception as e:
        print(f"Error parsing coordinate '{coord_str}': {e}")
        return None

class MQTTHandler:
    def __init__(self):
        # 初始化参数（保持不变）
        self.order_of_m = 3
        self.multiple = 3

        # 设备数据（初始化时设为None）
        self.latitude_1 = None
        self.longitude_1 = None
        self.corr_max_lags_ms_1 = None  # 初始化为None
        self.latitude_2 = None
        self.longitude_2 = None
        self.corr_max_lags_ms_2 = None  # 初始化为None

        # 新增严格更新标志
        self.corr1_changed = False
        self.corr2_changed = False

        # CSV文件初始化（保持不变）
        self.csv_file = "mqtt_data.csv"
        self.init_csv()

        # MQTT客户端（保持不变）
        self.client = self._create_client()

    def _create_client(self):
        # 原有客户端配置保持不变
        client_id = 'k1h20s5zVGz.MATLAB|securemode=2,signmethod=hmacsha256,timestamp=1743514388351|'
        username = 'MATLAB&k1h20s5zVGz'
        password = 'b4b2c5ddcab7e88a9824b7b973bdcfb8a4b2697f7689aa2f96d013a6732e1f75'

        client = mqtt.Client(
            client_id=client_id,
            callback_api_version=mqtt.CallbackAPIVersion.VERSION2
        )
        client.username_pw_set(username, password)
        client.on_connect = self.on_connect
        client.on_message = self.on_message
        client.reconnect_delay_set(min_delay=1, max_delay=120)
        return client

    def init_csv(self):
        # 原有CSV初始化保持不变
        header = ["time",
                  "latitude_1", "longitude_1", "corr_max_lags_ms_1",
                  "latitude_2", "longitude_2", "corr_max_lags_ms_2",
                  "distance", "flow_speed"]
        if not os.path.exists(self.csv_file):
            with open(self.csv_file, "w", newline="") as f:
                writer = csv.writer(f)
                writer.writerow(header)

    def on_connect(self, client, userdata, flags, reason_code, properties):
        # 原有连接逻辑保持不变
        if reason_code == 0:
            print("连接成功")
            topic = "/sys/k1h20s5zVGz/MATLAB/thing/event/property/post"
            client.subscribe(topic, qos=1)
            print(f"已订阅转发Topic: {topic}")
        else:
            print(f"连接失败，状态码: {reason_code}")

    def on_message(self, client, userdata, msg):
        try:
            payload = json.loads(msg.payload.decode())
            original_device = payload.get("deviceName")
            items = payload.get('items', {})

            print(f"收到来自 {original_device} 的转发数据")

            if original_device in ["STM32H71", "STM32H72"]:
                self._update_device_data(items, original_device)

            # 检查两个设备的corr是否都发生了实际变化
            if self.corr1_changed and self.corr2_changed:
                self.process_data()
                # 重置标志
                self.corr1_changed = False
                self.corr2_changed = False
        except Exception as e:
            print(f"处理消息异常: {e}")

    def _update_device_data(self, items, original_device):
        try:
            # 提取数据（保持不变）
            latitude_str = items.get("latitude", {}).get("value", "")
            longitude_str = items.get("longitude", {}).get("value", "")
            corr_max_lags_ms_value = items.get("corr_max_lags_ms", {}).get("value", None)
            order_of_m_value = items.get("order_of_m", {}).get("value", self.order_of_m)
            multiple_value = items.get("multiple", {}).get("value", self.multiple)

            # 解析经纬度（保持不变）
            latitude = parse_coordinate(latitude_str) if latitude_str else None
            longitude = parse_coordinate(longitude_str) if longitude_str else None

            # 更新数据时检测数值变化
            if original_device == "STM32H71":
                # 检查corr_max_lags_ms是否发生实际变化
                if corr_max_lags_ms_value is not None and corr_max_lags_ms_value != self.corr_max_lags_ms_1:
                    self.corr_max_lags_ms_1 = corr_max_lags_ms_value
                    self.corr1_changed = True  # 只有数值变化时标记
                # 经纬度直接更新（无需变化检查）
                if latitude is not None:
                    self.latitude_1 = latitude
                if longitude is not None:
                    self.longitude_1 = longitude
                self.order_of_m = order_of_m_value
                self.multiple = multiple_value
            elif original_device == "STM32H72":
                # 检查corr_max_lags_ms是否发生实际变化
                if corr_max_lags_ms_value is not None and corr_max_lags_ms_value != self.corr_max_lags_ms_2:
                    self.corr_max_lags_ms_2 = corr_max_lags_ms_value
                    self.corr2_changed = True  # 只有数值变化时标记
                # 经纬度直接更新（无需变化检查）
                if latitude is not None:
                    self.latitude_2 = latitude
                if longitude is not None:
                    self.longitude_2 = longitude

            print(f"更新 {original_device} 数据：纬度={latitude}, 经度={longitude}, corr_max_lags_ms={corr_max_lags_ms_value}")
        except Exception as e:
            print(f"Error updating device data: {e}")

    def calculate_distance(self):
        # 原有距离计算逻辑保持不变
        if self.latitude_1 and self.longitude_1 and self.latitude_2 and self.longitude_2:
            R = 6371.0
            lat1 = math.radians(self.latitude_1)
            lon1 = math.radians(self.longitude_1)
            lat2 = math.radians(self.latitude_2)
            lon2 = math.radians(self.longitude_2)

            dlat = lat2 - lat1
            dlon = lon2 - lon1

            a = math.sin(dlat / 2) ** 2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon / 2) ** 2
            c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
            distance = R * c
            return distance
        return 0

    def process_data(self):
        # 原有数据保存逻辑保持不变
        distance = self.calculate_distance()
        flow_speed = abs((distance / 2) * (1 / self.corr_max_lags_ms_1 - 1 / self.corr_max_lags_ms_2) * 1000)

        # 获取当前时间戳并向前取整到最近的10秒
        timestamp = time.time()
        rounded_timestamp = int(timestamp // 10) * 10
        current_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(rounded_timestamp))

        with open(self.csv_file, "a", newline="") as f:
            writer = csv.writer(f)
            writer.writerow([current_time,
                             self.latitude_1, self.longitude_1, self.corr_max_lags_ms_1,
                             self.latitude_2, self.longitude_2, self.corr_max_lags_ms_2,
                             distance, flow_speed])
        print(f"数据已记录：{current_time}, 距离={distance} 公里, 流速={flow_speed}")

    def start(self):
        # 原有启动逻辑保持不变
        self.client.connect("iot-06z00g00rbaa0u6.mqtt.iothub.aliyuncs.com", 1883)
        self.client.loop_forever()

if __name__ == "__main__":
    handler = MQTTHandler()
    try:
        handler.start()
    except KeyboardInterrupt:
        print("程序已终止")
        handler.client.disconnect()