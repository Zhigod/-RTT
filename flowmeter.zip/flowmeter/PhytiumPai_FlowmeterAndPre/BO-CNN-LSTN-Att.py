import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import MinMaxScaler
import torch
import torch.nn as nn
from sklearn.metrics import mean_squared_error
from torch.utils.data import DataLoader, TensorDataset
import torch.nn.functional as F
import torch.optim as optim
from skopt.space import Real, Integer
from skopt.utils import use_named_args
from skopt import gp_minimize
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import r2_score
import time

sns.set(style="whitegrid", palette="muted")  # 设置背景风格和配色方案
plt.rcParams["font.family"] = "Arial"  # 设置字体
plt.rcParams["font.size"] = 12  # 设置字体大小

# 替换为你的 Excel 文件路径
file_path = r'C:\Users\志\Desktop\流量数据\9月10月FATS流量结果.xlsx'

# 读取 Excel 数据
data_from_excel = pd.read_excel(file_path)

# 提取目标列 'discharge (m3/s)' 并创建数据框
data = pd.DataFrame({
    'Discharge': data_from_excel['discharge (m3/s)'][4098:6114]  # 替换为 Excel 文件中的实际列名[4098:6114]discharge (m3/s)
})

print(data.shape)

# 可视化原始数据
plt.figure(figsize=(12, 6))
plt.plot(data['Discharge'], label="Discharge (m³/s)", color='mediumslateblue', linewidth=2)
plt.xlabel("Time", fontsize=14)
plt.ylabel("Discharge (m³/s)", fontsize=14)
plt.title("Discharge Time Series", fontsize=16, weight='bold')
plt.legend(loc="upper right", fontsize=12)
plt.grid(True, linestyle='--', alpha=0.6)
plt.tight_layout()
plt.show()


# 数据预处理，创建样本
def create_samples(data, input_size, output_size):
    X, y = [], []
    for i in range(len(data) - input_size - output_size):
        X.append(data[i:i + input_size])
        y.append(data[i + input_size:i + input_size + output_size])
    return np.array(X), np.array(y)


# 定义输入和输出的窗口大小
in_size = 7  # 用过去  个时间步作为输入
out_size = 1  # 预测下一个时间步的值
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# 归一化数据
scaler = MinMaxScaler()
data_scaled = scaler.fit_transform(data['Discharge'].values.reshape(-1, 1)).flatten()  # 归一化 'Discharge'

# 创建输入输出样本
X, y = create_samples(data_scaled, in_size, out_size)

# 转换为 PyTorch 的张量
X_tensor = torch.Tensor(X).unsqueeze(1).to(device)  # 增加在第 1 维度的通道数，用于卷积
y_tensor = torch.Tensor(y).to(device)

# 划分训练集和测试集
train_size = int(len(X_tensor) * 0.8)
X_train, X_test = X_tensor[:train_size], X_tensor[train_size:]
y_train, y_test = y_tensor[:train_size], y_tensor[train_size:]

print(train_size)

# 创建 DataLoader
batch_size = 64
train_dataset = TensorDataset(X_train, y_train)
test_dataset = TensorDataset(X_test, y_test)

train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)


class QKVSelfAttention(nn.Module):
    def __init__(self, hidden_dim):
        super(QKVSelfAttention, self).__init__()
        # 定义 Q, K, V 投影层
        self.query_projection = nn.Linear(hidden_dim, hidden_dim)
        self.key_projection = nn.Linear(hidden_dim, hidden_dim)
        self.value_projection = nn.Linear(hidden_dim, hidden_dim)

    def forward(self, encoder_outputs):
        # encoder_outputs: (batch_size, sequence_length, hidden_dim)

        # 计算 Q, K, V
        Q = self.query_projection(encoder_outputs)  # (batch_size, sequence_length, hidden_dim)
        K = self.key_projection(encoder_outputs)  # (batch_size, sequence_length, hidden_dim)
        V = self.value_projection(encoder_outputs)  # (batch_size, sequence_length, hidden_dim)

        # 计算 Q 和 K 的点积并通过 softmax 获取注意力权重
        attention_scores = torch.bmm(Q, K.transpose(1, 2))  # (batch_size, sequence_length, sequence_length)
        attention_weights = F.softmax(attention_scores, dim=-1)  # (batch_size, sequence_length, sequence_length)

        # 计算加权后的 V
        attention_output = torch.bmm(attention_weights, V)  # (batch_size, sequence_length, hidden_dim)

        # 可以选择返回加权输出和注意力权重
        return attention_output, attention_weights


class SelfAttention(nn.Module):
    def __init__(self, hidden_dim):
        super(SelfAttention, self).__init__()
        self.projection = nn.Sequential(
            nn.Linear(hidden_dim, 64),  # hidden_dim 为lstm的隐藏层数
            nn.ReLU(True),
            nn.Linear(64, 1)
        )

    def forward(self, encoder_outputs):
        # encoder_outputs: (batch_size, sequence_length, hidden_dim)
        # 计算注意力得分，赋予权重
        energy = self.projection(encoder_outputs)  # (batch_size, sequence_length, 1)
        weights = F.softmax(energy.squeeze(-1), dim=1)  # (batch_size, sequence_length)

        # 应用注意力权重
        outputs = (encoder_outputs * weights.unsqueeze(-1)).sum(dim=1)  # (batch_size, hidden_dim)
        return outputs, weights


class CNN_LSTM(nn.Module):
    def __init__(self, input_size, hidden_size, output_size, kernel_size, num_layers):
        super(CNN_LSTM, self).__init__()
        self.conv1 = nn.Conv1d(input_size, hidden_size, kernel_size)  # 卷积层
        # self.BN1 = nn.BatchNorm1d(hidden_size)
        self.relu1 = nn.ReLU()
        self.pool = nn.MaxPool1d(kernel_size=2)  # 池化层
        self.lstm = nn.LSTM(hidden_size, hidden_size, num_layers, batch_first=True)
        # 添加自注意力层和注意力层
        # self.self_attention = SelfAttention(hidden_size)
        self.qkv_attention = QKVSelfAttention(hidden_size)
        self.fc = nn.Linear(hidden_size, output_size)

    def forward(self, x):
        # x = torch.relu(self.conv1(x))  # 卷积层激活函数   [64,1,7]-->[64,64,5]
        # x = self.pool(x)  # 池化层   [64,64,5]-->[64,64,2]
        # x = x.permute(0, 2, 1)  # permute 调整维度顺序  [64,64,2]-->[64,2,64]
        # out, _ = self.lstm(x)   # [64,2,64]
        # self_att_out, self_weights = self.self_attention(out)  # 自注意力层 [64,2,64]
        # output = self.fc(self_att_out)  # 经过全连接层 [64,1]
        # return output

        x = self.conv1(x)  # 卷积层激活函数   [64,1,7]-->[64,64,5]
        # x = self.BN1(x)
        x = self.relu1(x)
        x = self.pool(x)  # 池化层   [64,64,5]-->[64,64,2]
        x = x.permute(0, 2, 1)  # permute 调整维度顺序  [64,64,2]-->[64,2,64]
        out, _ = self.lstm(x)  # [64,2,64]
        # 使用 QKV 注意力层
        attention_output, attention_weights = self.qkv_attention(out)  # [64,2,64]
        # 取最后一个时间步的输出
        last_output = attention_output[:, -1, :]  # [64,64]
        output = self.fc(last_output)  # 经过全连接层 [64,1]
        return output


#  定义超参数
input_size = 1  # 特征数
hidden_size = 64
output_size = 1
num_layers = 2
kernel_size = 3  # 卷积核大小
learning_rate = 0.01

model = CNN_LSTM(input_size, hidden_size, output_size, kernel_size, num_layers).to(device)
criterion = nn.MSELoss()
optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)

num_epochs = 100
train_loss_list = []
test_loss_list = []
for epoch in range(num_epochs):
    model.train()
    running_loss = 0.0
    for X_batch, y_batch in train_loader:
        optimizer.zero_grad()
        # print("batch_size:{},{}".format(X_batch, X_batch.shape))
        outputs = model(X_batch)
        loss = criterion(outputs, y_batch)
        loss.backward()
        optimizer.step()
        running_loss += loss.item()
    train_loss_list.append(running_loss / len(train_loader))

    if (epoch + 1) % 10 == 0:
        print(f'Epoch [{epoch + 1}/{num_epochs}], Loss: {loss.item():.4f}')

model.eval()
with torch.no_grad():
    predicted = model(X_test).cpu().detach().numpy()  # 确保模型输出在 CPU
    predicted = scaler.inverse_transform(predicted)  # 反归一化
    actual = scaler.inverse_transform(y_test.cpu().numpy())  # 确保 y_test 也在 CPU

# 转为DataFrame便于可视化
predicted_df = pd.DataFrame(predicted, columns=['Discharge'])
actual_df = pd.DataFrame(actual, columns=['Discharge'])

colors = ['#1f77b4', '#ff7f0e']  # 蓝色：实际值，橙色：预测值
fig, axes = plt.subplots(1, 1, figsize=(12, 10))

# 标题和字体设置
fig.suptitle('Discharge Prediction Using LSTM', fontsize=16, weight='bold')

# 绘制实际值与预测值对比图
axes.plot(actual_df['Discharge'], color='blue', label='Actual Discharge', linewidth=1.5)
axes.plot(predicted_df['Discharge'], color='red', linestyle='--', label='Predicted Discharge', linewidth=1.5)
axes.set_title('Discharge Prediction', fontsize=14, weight='bold')
axes.set_ylabel('Discharge (m³/s)', fontsize=12)
axes.set_xlabel('Time', fontsize=12)
axes.legend(fontsize=10, loc='upper right')
axes.grid(True)

# 显示图形
plt.tight_layout(rect=[0, 0, 1, 0.96])
plt.show()

# 计算均方根误差 (RMSE)
rmse = np.sqrt(mean_squared_error(actual_df['Discharge'], predicted_df['Discharge']))
print(f'RMSE1: {rmse:.4f}')

# 计算平均绝对百分比误差 (MAPE)
mape = np.mean(np.abs((actual_df['Discharge'] - predicted_df['Discharge']) / actual_df['Discharge'])) * 100
print(f'MAPE1: {mape:.4f}%')

# 计算平均绝对误差 (MAE)
mae = mean_absolute_error(actual_df['Discharge'], predicted_df['Discharge'])
print(f'MAE: {mae:.4f}')

# 计算决定系数 (R^2)
r2 = r2_score(actual_df['Discharge'], predicted_df['Discharge'])
print(f'R^2: {r2:.4f}')

if __name__ == '__main__':
    lstm = CNN_LSTM(input_size, hidden_size, output_size, kernel_size, num_layers)
    print(lstm)


# 定义需要优化的超参数空间--贝叶斯优化部分

space = [
    Real(1e-5, 1e-1, name='learning_rate', prior='log-uniform'),
    Integer(10, 200, name='hidden_size'),
    Integer(1, 5, name='kernel_size'),
    Integer(1, 10, name='num_layers')
]

# 定义目标函数
@use_named_args(space)
def objective(**params):
    learning_rate = params['learning_rate']
    hidden_size = int(params['hidden_size'])  # 转换为Python内置int类型
    kernel_size = int(params['kernel_size'])
    num_layers = int(params['num_layers'])

    model = CNN_LSTM(input_size, hidden_size, output_size, kernel_size, num_layers).to(device)
    # criterion = nn.MSELoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)

    # 重新训练模型并记录验证损失
    for epoch in range(30):  # 为了节约时间，只训练30个epoch
        model.train()
        for X_batch, y_batch in train_loader:
            optimizer.zero_grad()
            output = model(X_batch)
            loss = criterion(output, y_batch)
            loss.backward()
            optimizer.step()

    # 在测试集上验证
    model.eval()
    test_loss = 0
    with torch.no_grad():
        for X_batch, y_batch in test_loader:
            output = model(X_batch)
            test_loss += criterion(output, y_batch).item()

    # 返回测试集上的平均损失
    return test_loss / len(test_loader)

# 运行贝叶斯优化

# 绘制超参数随迭代变化的图像
def plot_hyperparameter_optimization(result):
    # 超参数的变化图
    param_names = [dim.name for dim in space]  # 获取超参数名称
    n_params = len(param_names)

    # 为每个超参数创建一个图
    fig, axes = plt.subplots(n_params, 1, figsize=(10, 5 * n_params))

    if n_params == 1:
        axes = [axes]  # 保证axes是list类型

    for i, ax in enumerate(axes):
        # 提取当前超参数的历史记录
        param_history = [x[i] for x in result.x_iters]

        ax.plot(param_history, marker='o', linestyle='-', color='b')
        ax.set_title(f'Hyperparameter: {param_names[i]}', fontsize=14)
        ax.set_xlabel('Iteration', fontsize=12)
        ax.set_ylabel(param_names[i], fontsize=12)
        ax.grid(True)

    plt.tight_layout()
    plt.show()

# 绘制目标函数随迭代变化的图像
def plot_objective_function_optimization(result):
    # 目标函数（损失函数）随迭代变化的图像
    plt.figure(figsize=(10, 6))
    plt.plot(result.func_vals, marker='o', linestyle='-', color='r')
    plt.title('Objective Function (Loss) Optimization', fontsize=14)
    plt.xlabel('Iteration', fontsize=12)
    plt.ylabel('Objective Function Value (Loss)', fontsize=12)
    plt.grid(True)
    plt.show()

# 初始点数量及优化过程迭代次数
n_initial_points = 8  # 初始的随机搜索点  5-10
n_calls = 40        # 优化迭代次数  20-50

# 使用贝叶斯优化进行超参数调优
start_time = time.time()
# 使用贝叶斯优化进行超参数调优
result = gp_minimize(objective, space, n_calls=n_calls, n_initial_points=n_initial_points, random_state=42)

# 记录结束时间
end_time = time.time()
# 计算优化花费的时间
elapsed_time = end_time - start_time

# 输出最优超参数组合
print(f'Best Hyperparameters: \nLearning Rate: {result.x[0]:.6f}, Hidden Size: {result.x[1]}, Kernel Size: {result.x[2]}, Num Layers: {result.x[3]}')
# 调用可视化函数
plot_hyperparameter_optimization(result)
plot_objective_function_optimization(result)
# 输出贝叶斯优化所花的时间
print(f'Bayesian Optimization Time: {elapsed_time:.2f} seconds')

# 使用最优超参数重新训练LSTM模型
best_learning_rate = result.x[0]
best_hidden_size = int(result.x[1])  # 转换为Python的int类型
best_kernel_size = int(result.x[2])   # 同样转换为Python的int类型
best_num_layers = int(result.x[3])   # 同样转换为Python的int类型

model = CNN_LSTM(input_size, best_hidden_size, output_size, best_kernel_size, best_num_layers).to(device)
criterion = nn.MSELoss()
optimizer = torch.optim.Adam(model.parameters(), lr=best_learning_rate)

num_epochs = 100
train_loss_list = []
test_loss_list = []
for epoch in range(num_epochs):
    model.train()
    running_loss = 0.0
    for X_batch, y_batch in train_loader:
        optimizer.zero_grad()
        # print("batch_size:{},{}".format(X_batch, X_batch.shape))
        outputs = model(X_batch)
        loss = criterion(outputs, y_batch)
        loss.backward()
        optimizer.step()
        running_loss += loss.item()
    train_loss_list.append(running_loss / len(train_loader))

    if (epoch + 1) % 10 == 0:
        print(f'Epoch [{epoch + 1}/{num_epochs}], Loss: {loss.item():.4f}')

# 保存模型
torch.save(model.state_dict(), 'last_model.pth')
print("模型已保存为 last_model.pth")

model.eval()
with torch.no_grad():
    predicted = model(X_test).cpu().detach().numpy()  # 确保模型输出在 CPU
    predicted = scaler.inverse_transform(predicted)  # 反归一化
    actual = scaler.inverse_transform(y_test.cpu().numpy())  # 确保 y_test 也在 CPU

# 转为DataFrame便于可视化
predicted_df = pd.DataFrame(predicted, columns=['Discharge'])
actual_df = pd.DataFrame(actual, columns=['Discharge'])

colors = ['#1f77b4', '#ff7f0e']  # 蓝色：实际值，橙色：预测值
fig, axes = plt.subplots(1, 1, figsize=(12, 10))

# 标题和字体设置
fig.suptitle('Discharge Prediction Using LSTM and BO', fontsize=16, weight='bold')

# 绘制实际值与预测值对比图
axes.plot(actual_df['Discharge'], color='blue', label='Actual Discharge', linewidth=1.5)
axes.plot(predicted_df['Discharge'], color='green', linestyle='--', label='Predicted Discharge', linewidth=1.5)
axes.set_title('Discharge Prediction', fontsize=14, weight='bold')
axes.set_ylabel('Discharge (m³/s)', fontsize=12)
axes.set_xlabel('Time', fontsize=12)
axes.legend(fontsize=10, loc='upper right')
axes.grid(True)

# 显示图形
plt.tight_layout(rect=[0, 0, 1, 0.96])
plt.show()

# 计算均方根误差 (RMSE)
rmse = np.sqrt(mean_squared_error(actual_df['Discharge'], predicted_df['Discharge']))
print(f'RMSE2: {rmse:.4f}')

# 计算平均绝对百分比误差 (MAPE)
mape = np.mean(np.abs((actual_df['Discharge'] - predicted_df['Discharge']) / actual_df['Discharge'])) * 100
print(f'MAPE2: {mape:.4f}%')

# 计算平均绝对误差 (MAE)
mae = mean_absolute_error(actual_df['Discharge'], predicted_df['Discharge'])
print(f'MAE2: {mae:.4f}')

# 计算决定系数 (R^2)
r2 = r2_score(actual_df['Discharge'], predicted_df['Discharge'])
print(f'R^2 2: {r2:.4f}')

