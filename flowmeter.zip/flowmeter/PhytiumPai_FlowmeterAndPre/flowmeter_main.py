import pandas as pd
import json
import numpy as np
import torch
import time
import sys
import matplotlib
matplotlib.use("Qt5Agg")

from PyQt5.Qt import *
from FlowMeterUI2 import Ui_MainWindow
from matplotlib.backends.backend_qt5 import NavigationToolbar2QT as NavigationToolbar
from CNN_LSTM_Att_model import CNN_LSTM_Att
from LSTM_model import LSTM
from CNN_LSTM_model import CNN_LSTM
from sklearn.preprocessing import MinMaxScaler
import os
from PyQt5.QtCore import QDir
from PyQt5.QtWidgets import QFileDialog
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import joblib
from subscribe_csv import MQTTHandler


class Mplplot:
    def __init__(self, width=5, height=4, dpi=80):
        import matplotlib.pyplot as plt
        self.figure = plt.figure(figsize=(width, height), dpi=dpi)
        self.axes = self.figure.add_subplot(111)
        self.line = None

    def add_line(self, x_data, y_data, title="Actual Testing", xlabel="Time", ylabel="Discharge (m³/s)"):
        self.line, = self.axes.plot(x_data, y_data)
        self.axes.set_title(title)
        self.axes.set_xlabel(xlabel)
        self.axes.set_ylabel(ylabel)
        self.axes.grid(True)

    def add_line2(self, x, y, title="", xlabel="", ylabel="", color='blue', label=None):
        self.axes.plot(x, y, color=color, label=label)
        self.axes.set_title(title)
        self.axes.set_xlabel(xlabel)
        self.axes.set_ylabel(ylabel)
        if label:  # 如果提供了图例标签
            self.axes.legend()

    def draw(self):
        self.figure.canvas.draw()


# history_file_path = None  # 用于存放选中的历史文件路径


class Window(QMainWindow, Ui_MainWindow):
    def __init__(self, app):
        super(QMainWindow, self).__init__()
        self.app = app
        self.setup_ui()
        self.setWindowTitle("声层析测流系统")  # 设置窗口标题
        self.setWindowIcon(QIcon("水耗统计.png"))  # 设置窗口图标
        self.statusBar().hide()  # 先获取再隐藏
        self.setup_prediction_plot()  # 初始化预测图表
        self.setup_custom_plot()  # 初始化plot_view2_2区域的图
        self.update_data_thread = UpdateDataThread()  # 创建数据更新线程
        self.select_pre_thread = None  # 添加线程对象
        # 初始化打印线程
        self.MQTT_thread = None
        self.connect_signals()  # 绑定事件
        self.click_count = 0  # 初始化点击计数器
        self.file_path = 'mqtt_data.xlsx'  # Excel文件路径
        self.model = None
        self.is_plotting = False  # 标记是否正在绘图
        self.scaler = MinMaxScaler(feature_range=(0, 1))
        self.history_file_path = None  # 作为实例变量初始化


    def fix_text_browsers(self):
        """禁用所有QTextBrowser的滚动条和滚动功能"""
        # 获取窗口中所有的QTextBrowser对象
        text_browsers = self.findChildren(QTextBrowser)

        for tb in text_browsers:
            # 禁用滚动条
            tb.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
            tb.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)

            # 禁止文本编辑和交互
            tb.setReadOnly(True)
            tb.setOpenLinks(False)

            # 禁用鼠标滚轮事件
            tb.wheelEvent = lambda event: None

            # 确保内容不会超出可视区域
            tb.document().setDocumentMargin(0)
            tb.setLineWrapMode(QTextBrowser.NoWrap)

    def setup_ui(self):
        self.setupUi(self)
        # 初始化绘图区域
        self.phase_fig = Mplplot(width=5, height=4, dpi=80)
        self.fig_ntb = NavigationToolbar(self.phase_fig.figure.canvas, self)
        self.gridlayout = QGridLayout(self.plot_view1)
        self.gridlayout.addWidget(self.phase_fig.figure.canvas)
        self.gridlayout.addWidget(self.fig_ntb)
        # 固定所有QTextBrowser控件（假设您的UI中有多个）
        self.fix_text_browsers()

    def setup_prediction_plot(self):
        """初始化预测结果图表"""
        self.prediction_fig = Mplplot(width=5, height=4, dpi=80)
        self.prediction_ntb = NavigationToolbar(self.prediction_fig.figure.canvas, self)
        self.gridlayout2 = QGridLayout(self.plot_view2)  # 使用plot_view2作为容器
        self.gridlayout2.addWidget(self.prediction_fig.figure.canvas)
        self.gridlayout2.addWidget(self.prediction_ntb)

    def setup_custom_plot(self):
        """初始化自定义文件绘图区域 plot_view2_2"""
        self.custom_fig = Mplplot(width=5, height=4, dpi=80)
        self.custom_ntb = NavigationToolbar(self.custom_fig.figure.canvas, self)
        self.gridlayout3 = QGridLayout(self.plot_view2_2)  # 指定容器为 plot_view2_2
        self.gridlayout3.addWidget(self.custom_fig.figure.canvas)
        self.gridlayout3.addWidget(self.custom_ntb)

    def connect_signals(self):
        self.btn_dataget.clicked.connect(self.btn_dataget_clicked)
        self.btn_modelload.clicked.connect(self.btn_modelload_clicked)
        self.btn_pre.clicked.connect(self.btn_pre_clicked)
        self.update_data_thread._signal_update.connect(self.update_data_thread_slot)
        self.btn_connect.clicked.connect(self.toggle_MQTT_thread)
        self.btn_selectFile.clicked.connect(self.btn_selectFile_clicked)
        self.btn_selectPre.clicked.connect(self.btn_selectPre_clicked)
        self.btn_preAll.clicked.connect(self.btn_preAll_clicked)
        self.btn_clear.clicked.connect(self.btn_clear_clicked)

    def btn_dataget_clicked(self):
        self.click_count += 1
        if self.click_count % 2 == 1:  # 奇数次点击
            self.is_plotting = True
            self.btn_dataget.setText("停止获取")
            self.txt_status.setText("正在更新流量数据...")  # 添加状态显示
            # 每次都创建新的线程对象
            self.update_data_thread = UpdateDataThread()
            self.update_data_thread._signal_update.connect(self.update_data_thread_slot)
            self.update_data_thread.start()
        else:  # 偶数次点击
            self.is_plotting = False
            self.btn_dataget.setText("获取数据")
            self.txt_status.setText("已暂停更新流量数据")  # 添加状态显示
            self.update_data_thread.stop()  # 停止当前线程

    def update_data_thread_slot(self, data):
        # 线程回调函数，更新图表
        try:
            data = json.loads(data)
            # 更新距离显示（保留2位小数）
            self.txt_dist.setText(f"{data['distance']:.2f} 米")
            self.txt_lat1.setText(f"{data['latitude_1']:.4f}N {data['longitude_1']:.4f}E")
            self.txt_lat2.setText(f"{data['latitude_2']:.4f}N {data['longitude_2']:.4f}E")
            # 如果还没有创建曲线，先创建
            if self.phase_fig.line is None:
                self.phase_fig.add_line(data['x_data'], data['y_data'])
            else:
                # 更新曲线数据
                self.phase_fig.line.set_data(data['x_data'], data['y_data'])
                # 自动调整坐标轴范围
                self.phase_fig.axes.relim()
                self.phase_fig.axes.autoscale_view()
                self.txt_status.setText(f"数据更新时间: {time.strftime('%Y-%m-%d %H:%M:%S')}")  # 添加带时间戳的状态
            self.phase_fig.draw()  # 重绘图表
        except Exception as e:
            print(f"更新图表时出错: {e}")

    def toggle_MQTT_thread(self):
        if self.MQTT_thread and self.MQTT_thread.isRunning():
            # 停止线程
            self.MQTT_thread.stop()
            self.MQTT_thread = None
            self.btn_connect.setText("连接设备")
            print("MQTT线程已停止")
        else:
            # 启动线程
            self.MQTT_thread = MQTTConnectThread()
            self.MQTT_thread.start()
            self.btn_connect.setText("断开设备")
            print("MQTT线程已启动")

    def btn_selectPre_clicked(self):
        try:
            index = self.cmb_diffModel.currentIndex()
            if index == 0:
                # print(self.history_file_path)
                try:            # 加载模型
                    model_path0 = 'last_model.pth'
                    input_size0 = 1
                    hidden_size0 = 139
                    output_size0 = 1
                    kernel_size0 = 4
                    num_layers0 = 7

                    # 初始化模型并加载权重
                    self.model = CNN_LSTM_Att(input_size0, hidden_size0, output_size0, kernel_size0, num_layers0)
                    self.model.load_state_dict(torch.load(model_path0, map_location=torch.device('cpu')))
                    self.model.eval()

                    self.txt_status.setText(f"BO-CNN-LSTM-Att模型已成功加载: {model_path0}")
                except Exception as e:
                    self.txt_status.setText(f"模型加载失败: {e}")
                    return

                try:
                    # 读取数据文件（修改为你的实际路径）
                    file_path = self.history_file_path
                    if file_path is None:
                        self.txt_status.append("请先选择历史数据文件")
                        return
                    data_from_excel = pd.read_excel(file_path)

                    # 提取数据列并构造 DataFrame（列名请确认）
                    data = pd.DataFrame({'Discharge': data_from_excel['flow_discharge']})

                    self.txt_status.append("数据加载成功，开始预测...")

                    # ========== 数据预处理 ==========
                    def create_samples(data, input_size, output_size):
                        X, y = [], []
                        for i in range(len(data) - input_size - output_size):
                            X.append(data[i:i + input_size])
                            y.append(data[i + input_size:i + input_size + output_size])
                        return np.array(X), np.array(y)

                    in_size = 7
                    out_size = 1

                    scaler = MinMaxScaler()
                    data_scaled = scaler.fit_transform(data['Discharge'].values.reshape(-1, 1)).flatten()

                    X, y = create_samples(data_scaled, in_size, out_size)

                    # 转换为 PyTorch 张量，全作为测试集
                    X_tensor = torch.Tensor(X).unsqueeze(1)  # [batch, channel, seq]
                    y_tensor = torch.Tensor(y)

                    # 模型预测
                    with torch.no_grad():
                        predicted = self.model(X_tensor).cpu().detach().numpy()
                        predicted0 = scaler.inverse_transform(predicted)
                        actual0 = scaler.inverse_transform(y_tensor.cpu().numpy())

                    self.predicted_result0 = predicted0  # 可用于后续图表展示等
                    self.actual_result0 = actual0  # 可用于后续图表展示等

                    # 转成 DataFrame，列名保持一致
                    actual_df = pd.DataFrame({'Discharge': actual0.flatten()})
                    predicted_df = pd.DataFrame({'Discharge': predicted0.flatten()})

                    # 计算均方根误差 (RMSE)
                    rmse0 = np.sqrt(mean_squared_error(actual_df['Discharge'], predicted_df['Discharge']))
                    print(f'RMSE: {rmse0:.4f}')
                    self.tableWidget.setItem(0, 1, QTableWidgetItem(f"{rmse0:.4f}"))

                    # 计算平均绝对误差 (MAE)
                    mae0 = mean_absolute_error(actual_df['Discharge'], predicted_df['Discharge'])
                    print(f'MAE: {mae0:.4f}')
                    self.tableWidget.setItem(0, 0, QTableWidgetItem(f"{mae0:.4f}"))

                    # 计算决定系数 (R^2)
                    r20 = r2_score(actual_df['Discharge'], predicted_df['Discharge'])
                    print(f'R^2: {r20:.4f}')
                    self.tableWidget.setItem(0, 2, QTableWidgetItem(f"{r20:.4f}"))

                except Exception as e:
                    self.txt_status.append(f"预测失败: {str(e)}")

                # 清除旧图像
                self.custom_fig.axes.clear()

                # X 轴为样本索引
                x_data = list(range(len(actual0)))

                # 添加真实值曲线（黑色）
                self.custom_fig.add_line2(
                    x_data,
                    actual0.flatten(),
                    title="Prediction vs Actual",
                    xlabel="Sample Index",
                    ylabel="Discharge (m³/s)",
                    color='black',
                    label='Actual'
                )

                # 添加预测值曲线（红色）
                self.custom_fig.add_line2(
                    x_data,
                    predicted0.flatten(),
                    color='red',
                    label='Predicted'
                )

                # 显示图例并刷新绘图
                self.custom_fig.axes.legend()
                self.custom_fig.draw()

                self.txt_status.append("预测结果已绘制")

            elif index == 1:
                print("1")
                try:            # 加载模型
                    self.model = LSTM(input_size=1, hidden_size=50, output_size=1, num_layers=1)
                    # 加载参数
                    self.model.load_state_dict(torch.load('LSTM.pth', map_location=torch.device('cpu')))
                    self.model.eval()
                    self.txt_status.setText(f"BO-CNN-LSTM-Att模型已成功加载: LSTM.pth")
                except Exception as e:
                    self.txt_status.setText(f"模型加载失败: {e}")
                    return

                try:
                    # 读取数据文件
                    file_path = self.history_file_path
                    if file_path is None:
                        self.txt_status.append("请先选择历史数据文件")
                        return
                    data_from_excel = pd.read_excel(file_path)

                    # 提取数据列
                    data = pd.DataFrame({'Discharge': data_from_excel['flow_discharge']})

                    self.txt_status.append("数据加载成功，开始预测...")

                    # ========== 数据预处理 ==========
                    def create_samples_lstm(data, input_size, output_size):
                        X, y = [], []
                        for i in range(len(data) - input_size - output_size):
                            X.append(data[i:i + input_size])
                            y.append(data[i + input_size:i + input_size + output_size])
                        return np.array(X), np.array(y)

                    in_size = 7
                    out_size = 1

                    scaler = MinMaxScaler()
                    data_scaled = scaler.fit_transform(data['Discharge'].values.reshape(-1, 1)).flatten()

                    X, y = create_samples_lstm(data_scaled, in_size, out_size)

                    # 转为PyTorch张量，注意LSTM输入是 [batch, seq_len, feature_dim]
                    X_tensor = torch.Tensor(X).unsqueeze(-1)  # [batch, seq_len, 1]
                    y_tensor = torch.Tensor(y)

                    # 模型预测
                    with torch.no_grad():
                        predicted = self.model(X_tensor).cpu().detach().numpy()
                        predicted1 = scaler.inverse_transform(predicted)
                        actual1 = scaler.inverse_transform(y_tensor.cpu().numpy())

                    self.predicted_result1 = predicted1  # 保存预测结果

                    # 转成DataFrame
                    actual_df = pd.DataFrame({'Discharge': actual1.flatten()})
                    predicted_df = pd.DataFrame({'Discharge': predicted1.flatten()})

                    # 计算RMSE
                    rmse1 = np.sqrt(mean_squared_error(actual_df['Discharge'], predicted_df['Discharge']))
                    print(f'RMSE: {rmse1:.4f}')
                    self.tableWidget.setItem(1, 1, QTableWidgetItem(f"{rmse1:.4f}"))

                    # 计算MAE
                    mae1 = mean_absolute_error(actual_df['Discharge'], predicted_df['Discharge'])
                    print(f'MAE: {mae1:.4f}')
                    self.tableWidget.setItem(1, 0, QTableWidgetItem(f"{mae1:.4f}"))

                    # 计算R^2
                    r21 = r2_score(actual_df['Discharge'], predicted_df['Discharge'])
                    print(f'R^2: {r21:.4f}')
                    self.tableWidget.setItem(1, 2, QTableWidgetItem(f"{r21:.4f}"))

                except Exception as e:
                    self.txt_status.append(f"预测失败: {str(e)}")
                    return

                    # 清除旧图像
                self.custom_fig.axes.clear()

                # X轴为样本索引
                x_data = list(range(len(actual1)))

                # 添加真实值曲线（黑色）
                self.custom_fig.add_line2(
                    x_data,
                    actual1.flatten(),
                    title="Prediction vs Actual (LSTM)",
                    xlabel="Sample Index",
                    ylabel="Discharge (m³/s)",
                    color='black',
                    label='Actual'
                )

                # 添加预测值曲线（绿色）
                self.custom_fig.add_line2(
                    x_data,
                    predicted1.flatten(),
                    color='green',
                    label='Predicted'
                )

                # 显示图例并刷新绘图
                self.custom_fig.axes.legend()
                self.custom_fig.draw()

                self.txt_status.append("预测结果已绘制 (LSTM)")

            elif index == 2:
                print("2")
                try:            # 加载模型
                    self.model = CNN_LSTM(input_size=1, hidden_size=64, output_size=1, kernel_size=3, num_layers=2)
                    # 加载参数
                    self.model.load_state_dict(torch.load('CNN-LSTM.pth', map_location=torch.device('cpu')))
                    self.model.eval()
                    self.txt_status.setText(f"CNN-LSTM模型已成功加载: CNN-LSTM.pth")
                except Exception as e:
                    self.txt_status.setText(f"模型加载失败: {e}")
                    return

                try:
                    # 读取数据文件
                    file_path = self.history_file_path
                    if file_path is None:
                        self.txt_status.append("请先选择历史数据文件")
                        return
                    data_from_excel = pd.read_excel(file_path)

                    # 提取数据列
                    data = pd.DataFrame({'Discharge': data_from_excel['flow_discharge']})

                    self.txt_status.append("数据加载成功，开始预测...")

                    # ========== 数据预处理 ==========
                    def create_samples_cnn_lstm(data, input_size, output_size):
                        X, y = [], []
                        for i in range(len(data) - input_size - output_size):
                            X.append(data[i:i + input_size])
                            y.append(data[i + input_size:i + input_size + output_size])
                        return np.array(X), np.array(y)

                    in_size = 7
                    out_size = 1

                    scaler = MinMaxScaler()
                    data_scaled = scaler.fit_transform(data['Discharge'].values.reshape(-1, 1)).flatten()

                    X, y = create_samples_cnn_lstm(data_scaled, in_size, out_size)

                    # 转为PyTorch张量，CNN-LSTM需要 [batch, channel, seq_len]
                    X_tensor = torch.Tensor(X).unsqueeze(1)  # [batch, channel, seq_len]
                    y_tensor = torch.Tensor(y)

                    # 模型预测
                    with torch.no_grad():
                        predicted = self.model(X_tensor).cpu().detach().numpy()
                        predicted2 = scaler.inverse_transform(predicted)
                        actual2 = scaler.inverse_transform(y_tensor.cpu().numpy())

                    self.txt_status.append(f"预测完成，共 {len(predicted)} 条数据")
                    self.predicted_result2 = predicted2  # 保存预测结果

                    # 转成DataFrame
                    actual_df = pd.DataFrame({'Discharge': actual2.flatten()})
                    predicted_df = pd.DataFrame({'Discharge': predicted2.flatten()})

                    # 计算RMSE
                    rmse2 = np.sqrt(mean_squared_error(actual_df['Discharge'], predicted_df['Discharge']))
                    print(f'RMSE: {rmse2:.4f}')
                    self.tableWidget.setItem(2, 1, QTableWidgetItem(f"{rmse2:.4f}"))

                    # 计算MAE
                    mae2 = mean_absolute_error(actual_df['Discharge'], predicted_df['Discharge'])
                    print(f'MAE: {mae2:.4f}')
                    self.tableWidget.setItem(2, 0, QTableWidgetItem(f"{mae2:.4f}"))

                    # 计算R^2
                    r22 = r2_score(actual_df['Discharge'], predicted_df['Discharge'])
                    print(f'R^2: {r22:.4f}')
                    self.tableWidget.setItem(2, 2, QTableWidgetItem(f"{r22:.4f}"))

                except Exception as e:
                    self.txt_status.append(f"预测失败: {str(e)}")
                    return

                    # 清除旧图像
                self.custom_fig.axes.clear()

                # X轴为样本索引
                x_data = list(range(len(actual2)))

                # 添加真实值曲线（黑色）
                self.custom_fig.add_line2(
                    x_data,
                    actual2.flatten(),
                    title="Prediction vs Actual (CNN-LSTM)",
                    xlabel="Sample Index",
                    ylabel="Discharge (m³/s)",
                    color='black',
                    label='Actual'
                )

                # 添加预测值曲线（蓝色）
                self.custom_fig.add_line2(
                    x_data,
                    predicted2.flatten(),
                    color='blue',
                    label='Predicted'
                )

                # 显示图例并刷新绘图
                self.custom_fig.axes.legend()
                self.custom_fig.draw()

                self.txt_status.append("预测结果已绘制 (CNN-LSTM)")

            elif index == 3:
                try:
                    # 加载已保存的 XGBoost 模型
                    self.model = joblib.load('XGBoost.pkl')
                    self.txt_status.setText("XGBoost模型已成功加载: XGBoost.pkl")
                except Exception as e:
                    self.txt_status.setText(f"模型加载失败: {e}")
                    return

                try:
                    # 读取数据文件
                    file_path = self.history_file_path
                    if file_path is None:
                        self.txt_status.append("请先选择历史数据文件")
                        return
                    data_from_excel = pd.read_excel(file_path)

                    # 提取数据列
                    data = pd.DataFrame({'Discharge': data_from_excel['flow_discharge']})

                    data['t'] = np.arange(len(data))
                    data.rename(columns={'Discharge': 'y'}, inplace=True)

                    # 数据转换为监督学习格式
                    def create_lag_features(data, lags=7):
                        df = data.copy()
                        for i in range(1, lags + 1):
                            df[f'lag_{i}'] = df['y'].shift(i)
                        df.dropna(inplace=True)
                        return df

                    df_lagged = create_lag_features(data, lags=7)
                    X_test = df_lagged.drop(columns=['y'])  # 全部作为测试集
                    y_test3 = df_lagged['y']  # 全部作为测试集的标签

                    y_pred3 = self.model.predict(X_test)

                    self.predicted_result3 = y_pred3  # 保存预测结果

                    # 转成 DataFrame
                    actual_df = pd.DataFrame({'Discharge': y_test3.values})
                    predicted_df = pd.DataFrame({'Discharge': y_pred3})

                    # 计算RMSE
                    rmse3 = np.sqrt(mean_squared_error(actual_df['Discharge'], predicted_df['Discharge']))
                    print(f'RMSE: {rmse3:.4f}')
                    self.tableWidget.setItem(3, 1, QTableWidgetItem(f"{rmse3:.4f}"))

                    # 计算MAE
                    mae3 = mean_absolute_error(actual_df['Discharge'], predicted_df['Discharge'])
                    print(f'MAE: {mae3:.4f}')
                    self.tableWidget.setItem(3, 0, QTableWidgetItem(f"{mae3:.4f}"))

                    # 计算R²
                    r23 = r2_score(actual_df['Discharge'], predicted_df['Discharge'])
                    print(f'R²: {r23:.4f}')
                    self.tableWidget.setItem(3, 2, QTableWidgetItem(f"{r23:.4f}"))

                    # ================= 绘图 ====================
                    self.custom_fig.axes.clear()

                    x_data = list(range(len(y_test3)))

                    # 添加真实值曲线
                    self.custom_fig.add_line2(
                        x_data,
                        y_test3.values.flatten(),
                        title="Prediction vs Actual (XGBoost)",
                        xlabel="Sample Index",
                        ylabel="Discharge (m³/s)",
                        color='black',
                        label='Actual'
                    )

                    # 添加预测值曲线
                    self.custom_fig.add_line2(
                        x_data,
                        y_pred3.flatten(),
                        color='orange',
                        label='Predicted'
                    )

                    self.custom_fig.axes.legend()
                    self.custom_fig.draw()

                    self.txt_status.append("预测结果已绘制 (XGBoost)")

                except Exception as e:
                    self.txt_status.append(f"预测失败: {str(e)}")
                    return

            elif index == 4:
                print("4")
                try:
                    # 加载已保存的LSTM_SVR模型
                    self.model = LSTM(input_size=1, hidden_size=25, output_size=1)
                    self.model.load_state_dict(torch.load('lstm_model4.pth'))
                    self.model.eval()
                    self.svr_loaded = joblib.load('svr_model.pkl')
                    self.txt_status.setText("LSTM_SVR模型已成功加载")
                except Exception as e:
                    self.txt_status.setText(f"模型加载失败: {e}")
                    return

                try:
                    # 读取数据文件
                    file_path = self.history_file_path
                    if file_path is None:
                        self.txt_status.append("请先选择历史数据文件")
                        return
                    data_from_excel = pd.read_excel(file_path)

                    # 提取数据列
                    data = pd.DataFrame({'Discharge': data_from_excel['flow_discharge']})
                    # 归一化数据
                    scaler = MinMaxScaler(feature_range=(0, 1))
                    data['Discharge'] = scaler.fit_transform(data[['Discharge']])
                    window_size = 7

                    def create_sequences(data, window_size):
                        sequences, targets = [], []
                        for i in range(len(data) - window_size):
                            sequences.append(data[i:i + window_size])
                            targets.append(data[i + window_size])
                        return np.array(sequences), np.array(targets)

                    X, y = create_sequences(data['Discharge'].values, window_size)

                    # 转为Torch张量
                    Xtorch = torch.FloatTensor(X).unsqueeze(-1)
                    ytorch = torch.FloatTensor(y)

                    with torch.no_grad():
                        lstm_features_test = self.model(Xtorch).squeeze().numpy()

                    # SVR进行最终预测
                    y_pred_scaled = self.svr_loaded.predict(lstm_features_test.reshape(-1, 1))

                    y_pred4 = scaler.inverse_transform(y_pred_scaled.reshape(-1, 1)).flatten()
                    y_true4 = scaler.inverse_transform(y.reshape(-1, 1)).flatten()

                    self.predicted_result4 = y_pred4  # 保存预测结果

                    # 转成 DataFrame
                    actual_df = pd.DataFrame({'Discharge': y_true4})
                    predicted_df = pd.DataFrame({'Discharge': y_pred4})

                    # 计算RMSE
                    rmse4 = np.sqrt(mean_squared_error(actual_df['Discharge'], predicted_df['Discharge']))
                    print(f'RMSE: {rmse4:.4f}')
                    self.tableWidget.setItem(4, 1, QTableWidgetItem(f"{rmse4:.4f}"))

                    # 计算MAE
                    mae4 = mean_absolute_error(actual_df['Discharge'], predicted_df['Discharge'])
                    print(f'MAE: {mae4:.4f}')
                    self.tableWidget.setItem(4, 0, QTableWidgetItem(f"{mae4:.4f}"))

                    # 计算R²
                    r24 = r2_score(actual_df['Discharge'], predicted_df['Discharge'])
                    print(f'R²: {r24:.4f}')
                    self.tableWidget.setItem(4, 2, QTableWidgetItem(f"{r24:.4f}"))

                    # ================= 绘图 ====================
                    self.custom_fig.axes.clear()

                    x_data = list(range(len(y_true4)))

                    # 添加真实值曲线
                    self.custom_fig.add_line2(
                        x_data,
                        y_true4,
                        title="Prediction vs Actual (LSTM + SVR)",
                        xlabel="Sample Index",
                        ylabel="Discharge (m³/s)",
                        color='black',
                        label='Actual'
                    )

                    # 添加预测值曲线
                    self.custom_fig.add_line2(
                        x_data,
                        y_pred4,
                        color='purple',
                        label='Predicted'
                    )

                    self.custom_fig.axes.legend()
                    self.custom_fig.draw()

                    self.txt_status.append("预测结果已绘制 (LSTM + SVR)")

                except Exception as e:
                    self.txt_status.append(f"预测失败: {str(e)}")
                    return

        except Exception as e:
            print(f"线程错误: {str(e)}")

    def btn_preAll_clicked(self):
        print("quanbu")
        try:
            for i in range(5):
                self.cmb_diffModel.setCurrentIndex(i)
                self.btn_selectPre_clicked()

            # 去掉 predicted_result3 和 predicted_result4 的第一个元素
            self.predicted_result3 = np.reshape(self.predicted_result3[1:], (-1, 1))
            self.predicted_result4 = np.reshape(self.predicted_result4[1:], (-1, 1))

            # print(self.predicted_result0.shape)
            # print(self.predicted_result1.shape)
            # print(self.predicted_result2.shape)
            # print(self.predicted_result3.shape)
            # print(self.predicted_result4.shape)

            self.custom_fig.axes.clear()

            x_data = list(range(len(self.predicted_result0)))
            y_true = self.actual_result0

            # 添加真实值曲线
            self.custom_fig.add_line2(
                x_data,
                y_true,
                title="Prediction vs Actual",
                xlabel="Sample Index",
                ylabel="Discharge (m³/s)",
                color='black',
                label='Actual'
            )

            # 添加预测值曲线
            self.custom_fig.add_line2(
                x_data,
                self.predicted_result0,
                color='red',
                label='BO-CNN-LSTM-Att'
            )

            self.custom_fig.add_line2(
                x_data,
                self.predicted_result1,
                color='green',
                label='LSTM'
            )

            self.custom_fig.add_line2(
                x_data,
                self.predicted_result2,
                color='blue',
                label='CNN-LSTM'
            )

            self.custom_fig.add_line2(
                x_data,
                self.predicted_result3,
                color='orange',
                label='XGBoost'
            )

            self.custom_fig.add_line2(
                x_data,
                self.predicted_result4,
                color='purple',
                label='LSTM-SVR'
            )

            self.custom_fig.axes.legend()
            self.custom_fig.draw()

            self.txt_status.append("所有对比模型预测结果已绘制")
        except Exception as e:
            self.txt_status.append(f"预测失败: {str(e)}")
            return

    def btn_clear_clicked(self):
        print("clear")
        try:
            # 清除图像
            self.custom_fig.axes.clear()
            self.custom_fig.draw()

            # 清除表格内容
            row_count = self.tableWidget.rowCount()
            column_count = self.tableWidget.columnCount()
            for i in range(row_count):
                for j in range(column_count):
                    self.tableWidget.setItem(i, j, QTableWidgetItem(""))

            # 更新状态栏
            self.txt_status.append("已清除图像和表格内容")

        except Exception as e:
            print(f"清除错误: {str(e)}")
            self.txt_status.append(f"清除失败: {str(e)}")

    def update_status_from_select_pre(self, msg):
        self.txt_status.setText(msg)

    def btn_modelload_clicked(self):
        try:
            model_path = 'last_model.pth'
            input_size = 1
            hidden_size = 139
            output_size = 1
            kernel_size = 4
            num_layers = 7

            # 初始化模型并加载权重
            self.model = CNN_LSTM_Att(input_size, hidden_size, output_size, kernel_size, num_layers)
            # self.model.load_state_dict(torch.load(model_path))
            self.model.load_state_dict(torch.load(model_path, map_location=torch.device('cpu')))
            self.model.eval()

            self.txt_status.setText(f"模型已成功加载: {model_path}")
        except Exception as e:
            self.txt_status.setText(f"模型加载失败: {e}")

    def pre_onetime(self):
        try:
            if self.model is None:
                self.txt_status.setText("请先加载模型")
                return

            # 1. 读取历史数据
            df = pd.read_excel(self.file_path)
            if len(df) < 7:
                self.txt_status.setText("错误：需要至少7个历史数据点")
                return

            # 2. 获取初始7个数据点和最新时间
            historical_data = df['flow_discharge'].values[-7:].reshape(-1, 1)
            last_time = pd.to_datetime(df['Time'].iloc[-1])

            # 3. 生成预测时间点（每次+5分钟）
            pred_times = [last_time + pd.Timedelta(minutes=5 * (i + 1)) for i in range(6)]
            pred_times_str = [t.strftime('%Y-%m-%d %H:%M') for t in pred_times]

            # 4. 清空之前的结果显示
            for i in range(1, 7):
                getattr(self, f'txt_pre{i}').clear()

            predictions = []  # 存储预测值

            # 5. 开始6次滚动预测
            for i in range(6):
                # 创建新的归一化器（建议改成使用训练时的 scaler，如果有保存的话）
                scaler = MinMaxScaler()
                scaler.fit(historical_data[-7:])  # 每次根据最新的7个数据拟合

                # 数据归一化
                input_scaled = scaler.transform(historical_data[-7:]).flatten()

                # 构建输入形状为 (1, 1, 7)
                X_input = np.array(input_scaled).reshape(1, 1, 7)
                X_tensor = torch.tensor(X_input, dtype=torch.float32)

                # 预测
                with torch.no_grad():
                    predicted_scaled = self.model(X_tensor).numpy()
                    predicted_value = scaler.inverse_transform(predicted_scaled.reshape(-1, 1))[0][0]

                predictions.append(predicted_value)

                # 更新文本框显示
                getattr(self, f'txt_pre{i + 1}').setText(f"{predicted_value:.2f} m³/s")

                # 将预测值加入历史数据用于下一轮预测
                historical_data = np.append(historical_data, predicted_value).reshape(-1, 1)

                # 更新状态栏
                self.txt_status.setText(f"正在进行第 {i + 1} 次预测...")
                QApplication.processEvents()
                time.sleep(0.3)

            # 6. 绘图
            self.plot_predictions(pred_times_str, predictions)
            self.txt_status.setText("6次滚动预测完成！")

        except Exception as e:
            self.txt_status.setText(f"预测失败: {str(e)}")

    def plot_predictions(self, times, values):
        """在plot_view2中绘制预测曲线"""
        # 清除旧图形
        self.prediction_fig.axes.clear()

        # 简化时间显示格式（只显示小时:分钟）
        short_times = [t.split()[-1][:5] for t in times]
        # 绘制新曲线
        self.prediction_fig.add_line(short_times, values)

        # 设置图表格式
        self.prediction_fig.axes.set_title("Prediction")
        self.prediction_fig.axes.set_xlabel("Time")
        self.prediction_fig.axes.set_ylabel("Discharge (m³/s)")
        # plt.setp(self.prediction_fig.axes.get_xticklabels(), rotation=45, ha='right')

        # 刷新显示
        self.prediction_fig.draw()

    def btn_pre_clicked(self):
        self.pre_onetime()

    def draw_custom_file_plot(self, file_path):
        try:
            df = pd.read_excel(file_path) if file_path.endswith('.xlsx') else pd.read_csv(file_path)
            if 'flow_discharge' not in df.columns:
                self.txt_status.setText("文件中未找到 'flow_discharge' 列")
                return
            # 清除旧图像
            self.custom_fig.axes.clear()

            x_data = range(len(df))  # 或者 df.index 也行，推荐更直观的是 range
            y_data = df['flow_discharge'].values

            # self.custom_fig.add_line(x_data, y_data, title="Comparison of historical data", xlabel="Data Sample", ylabel="Discharge (m³/s)")
            self.custom_fig.add_line2(
                x_data, y_data,
                title="Comparison of historical data",
                xlabel="Sample Index",
                ylabel="Discharge (m³/s)",
                color='black',
                label='historical data'
            )
            self.custom_fig.draw()
            self.txt_status.setText("自定义文件数据绘图完成")
        except Exception as e:
            self.txt_status.setText(f"绘图出错: {e}")

    def btn_selectFile_clicked(self):
        try:
            file_dialog = QFileDialog(self)
            file_dialog.setWindowTitle("选择Excel或CSV数据文件")
            file_dialog.setNameFilter("数据文件 (*.xlsx *.xls *.csv)")
            file_dialog.setDirectory(QDir.currentPath())

            if file_dialog.exec_() == QFileDialog.Accepted:
                selected_file = file_dialog.selectedFiles()[0]
                # self.file_path = selected_file
                self.history_file_path = selected_file
                filename = os.path.basename(selected_file)
                self.txt_status.setText(f"已选择文件: {filename}")
                self.txt_fileName.setText(filename)

                # 文件选择完后立即绘图
                self.draw_custom_file_plot(self.history_file_path)

            else:
                self.txt_status.setText("未选择文件")
        except Exception as e:
            self.txt_status.setText(f"打开文件时出错: {e}")


class UpdateDataThread(QThread):
    _signal_update = pyqtSignal(str)  # 信号

    def __init__(self, parent=None):
        super(UpdateDataThread, self).__init__(parent)
        self.qmut = QMutex()
        self.is_running = True
        self.file_path = 'mqtt_data.xlsx'    # 可以更改

    def run(self):
        while self.is_running:
            try:
                # 读取Excel文件
                df = pd.read_excel(self.file_path)
                # 转换时间格式
                df['Time'] = pd.to_datetime(df['Time']).dt.strftime('%Y-%m-%d %H:%M')

                # 准备数据
                x_data = df['Time'].values
                y_data = df['flow_discharge'].values

                # 获取最新一条数据
                latest_data = df.iloc[-1]

                # 发送数据更新信号
                self._signal_update.emit(json.dumps({
                    'x_data': x_data.tolist() if hasattr(x_data, 'tolist') else list(x_data),
                    'y_data': y_data.tolist() if hasattr(y_data, 'tolist') else list(y_data),
                    'distance': float(latest_data['distance']),  # 确保转换为float
                    'latitude_1': float(latest_data['latitude_1']),
                    'latitude_2': float(latest_data['latitude_2']),
                    'longitude_1': float(latest_data['longitude_1']),
                    'longitude_2': float(latest_data['longitude_2'])
                }))

            except Exception as e:
                print(f"读取文件出错: {e}")

            # 等待5秒
            # for _ in range(5):
            #     if not self.is_running:
            #         break
            time.sleep(5)

    def stop(self):
        # 停止线程
        self.is_running = False
        self.wait()


class MQTTConnectThread(QThread):
    def __init__(self):
        super().__init__()
        self.handler = MQTTHandler()  # 提前创建handler
        self._running = False  # 使用属性控制状态

    def run(self):
        self._running = True
        try:
            self.handler.start()
        except Exception as e:
            print(f"MQTT错误: {e}")
        finally:
            self._running = False

    def stop(self):
        if self._running:
            self.handler.client.disconnect()  # 先断开MQTT连接
            self.handler.client.loop_stop()   # 停止事件循环
            self.quit()                       # 退出线程
            if not self.wait(2000):           # 等待2秒线程结束
                self.terminate()              # 强制终止
            print("MQTT线程已停止")

    def is_running(self):
        return self._running


def main():
    app = QApplication(sys.argv)
    mywindow = Window(app)
    mywindow.show()
    sys.exit(app.exec_())


if __name__ == '__main__':
    main()