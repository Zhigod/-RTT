import torch
import torch.nn as nn


class CNN_LSTM(nn.Module):
    def __init__(self, input_size, hidden_size, output_size, kernel_size, num_layers=1):
        super(CNN_LSTM, self).__init__()
        self.conv1 = nn.Conv1d(input_size, hidden_size, kernel_size)  # 卷积层
        self.pool = nn.MaxPool1d(kernel_size=2)  # 池化层
        self.lstm = nn.LSTM(hidden_size, hidden_size, num_layers, batch_first=True)
        self.fc = nn.Linear(hidden_size, output_size)

    def forward(self, x):
        x = torch.relu(self.conv1(x))  # 卷积层激活函数   [64,1,7]-->[64,64,5]
        x = self.pool(x)  # 池化层   [64,64,5]-->[64,64,2]
        x = x.permute(0, 2, 1)  # permute 调整维度顺序  [64,64,2]-->[64,2,64]
        out, _ = self.lstm(x)   # [64,2,64]
        out = self.fc(out[:, -1, :])   # [64,1]
        return out