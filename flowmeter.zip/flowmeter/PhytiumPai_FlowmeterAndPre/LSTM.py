import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler
import torch
import torch.nn as nn
from sklearn.metrics import mean_squared_error
import torch.optim as optim
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import r2_score

# 替换为 Excel 文件路径
file_path = r'C:\Users\志\Desktop\流量数据\9月10月FATS流量结果.xlsx'

# 读取 Excel 数据
data_from_excel = pd.read_excel(file_path)

# 提取目标列 'Discharge' 并创建数据框
data = pd.DataFrame({
        'Discharge': data_from_excel['discharge (m3/s)'][4098:6114]  # 替换为 Excel 文件中的实际列名[4098:6114]
})

# 查看
print(data.shape)

scaler = MinMaxScaler(feature_range=(0, 1))
data_scaled = scaler.fit_transform(data)

train_size = int(len(data_scaled) * 0.8)
train_data = data_scaled[:train_size]
test_data = data_scaled[train_size:]

print(train_size)

def create_sequences(data, seq_length):
    xs, ys = [], []
    for i in range(len(data) - seq_length):
        x = data[i:i + seq_length]
        y = data[i + seq_length]
        xs.append(x)
        ys.append(y)
    return np.array(xs), np.array(ys)


seq_length = 7  # 用前7的数据预测第8
X_train, y_train = create_sequences(train_data, seq_length)
X_test, y_test = create_sequences(test_data, seq_length)

print(X_train.shape)

class LSTM(nn.Module):
    def __init__(self, input_size, hidden_size, output_size, num_layers=1):
        super(LSTM, self).__init__()
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers, batch_first=True)
        self.fc = nn.Linear(hidden_size, output_size)

    def forward(self, x):
        out, _ = self.lstm(x)
        out = self.fc(out[:, -1, :])
        return out


#  定义超参数
input_size = 1  # 特征数
hidden_size = 50
output_size = 1
num_layers = 1

model = LSTM(input_size, hidden_size, output_size, num_layers)
criterion = nn.MSELoss()
optimizer = torch.optim.Adam(model.parameters(), lr=0.01)

num_epochs = 50
for epoch in range(num_epochs):
    model.train()
    optimizer.zero_grad()
    outputs = model(torch.Tensor(X_train))
    loss = criterion(outputs, torch.Tensor(y_train))
    loss.backward()
    optimizer.step()

    if (epoch + 1) % 10 == 0:
        print(f'Epoch [{epoch + 1}/{num_epochs}], Loss: {loss.item():.4f}')

# 保存模型
torch.save(model.state_dict(), 'LSTM.pth')
print("模型已保存为 LSTM.pth")


model.eval()
with torch.no_grad():
    predicted = model(torch.Tensor(X_test)).detach().numpy()
    predicted = scaler.inverse_transform(predicted)
    actual = scaler.inverse_transform(y_test)

# 转为DataFrame便于可视化
predicted_df = pd.DataFrame(predicted, columns=['Discharge'])
actual_df = pd.DataFrame(actual, columns=['Discharge'])

colors = ['#1f77b4', '#ff7f0e']  # 蓝色：实际值，橙色：预测值
fig, axes = plt.subplots(1, 1, figsize=(12, 10))

# 标题和字体设置
fig.suptitle('Discharge Prediction Using LSTM', fontsize=16, weight='bold')

# 绘制实际值与预测值对比图
axes.plot(actual_df['Discharge'], color='blue', label='Actual Discharge', linewidth=1.5)
axes.plot(predicted_df['Discharge'], color='red', linestyle='--', label='Predicted Discharge', linewidth=1.5)
axes.set_title('Discharge Prediction', fontsize=14, weight='bold')
axes.set_ylabel('Discharge (m³/s)', fontsize=12)
axes.set_xlabel('Time', fontsize=12)
axes.legend(fontsize=10, loc='upper right')
axes.grid(True)

# 显示图形
plt.tight_layout(rect=[0, 0, 1, 0.96])
plt.show()

# 计算均方根误差 (RMSE)
rmse_LSTM = np.sqrt(
    mean_squared_error(actual_df['Discharge'], predicted_df['Discharge']))
print(f'RMSE_LSTM: {rmse_LSTM:.4f}')

# 计算平均绝对百分比误差 (MAPE)
mape_LSTM = np.mean(np.abs(
    (actual_df['Discharge'] - predicted_df['Discharge']) / actual_df[
        'Discharge'])) * 100
print(f'MAPE_LSTM: {mape_LSTM:.4f}%')

# 计算平均绝对误差 (MAE)
mae_LSTM = mean_absolute_error(actual_df['Discharge'], predicted_df['Discharge'])
print(f'MAE_LSTM: {mae_LSTM:.4f}')

# 计算决定系数 (R^2)
r2_LSTM = r2_score(actual_df['Discharge'], predicted_df['Discharge'])
print(f'R^2_LSTM: {r2_LSTM:.4f}')