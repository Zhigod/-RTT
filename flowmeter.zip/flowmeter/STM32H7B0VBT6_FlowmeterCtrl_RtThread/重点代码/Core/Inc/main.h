/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32h7xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define KEY1_Pin GPIO_PIN_2
#define KEY1_GPIO_Port GPIOE
#define KEY2_Pin GPIO_PIN_3
#define KEY2_GPIO_Port GPIOE
#define KEY3_Pin GPIO_PIN_4
#define KEY3_GPIO_Port GPIOE
#define SD_Inser_Pin GPIO_PIN_5
#define SD_Inser_GPIO_Port GPIOE
#define PWM_GEN_Pin GPIO_PIN_1
#define PWM_GEN_GPIO_Port GPIOA
#define GNSS_1PPS_Pin GPIO_PIN_10
#define GNSS_1PPS_GPIO_Port GPIOE
#define GNSS_1PPS_EXTI_IRQn EXTI15_10_IRQn
#define GNSS_VBUS_EN_Pin GPIO_PIN_15
#define GNSS_VBUS_EN_GPIO_Port GPIOE
#define GNSS_RXD_Pin GPIO_PIN_10
#define GNSS_RXD_GPIO_Port GPIOB
#define GNSS_TXD_Pin GPIO_PIN_11
#define GNSS_TXD_GPIO_Port GPIOB
#define OLED_CS_Pin GPIO_PIN_12
#define OLED_CS_GPIO_Port GPIOB
#define OLED_DC_Pin GPIO_PIN_14
#define OLED_DC_GPIO_Port GPIOB
#define OLED_RES_Pin GPIO_PIN_8
#define OLED_RES_GPIO_Port GPIOD
#define GPRS_VBUS_EN_Pin GPIO_PIN_10
#define GPRS_VBUS_EN_GPIO_Port GPIOD
#define GPRS_RESET_Pin GPIO_PIN_11
#define GPRS_RESET_GPIO_Port GPIOD
#define GPRS_PWRUP_Pin GPIO_PIN_13
#define GPRS_PWRUP_GPIO_Port GPIOD
#define EC800E_RXD_Pin GPIO_PIN_6
#define EC800E_RXD_GPIO_Port GPIOC
#define EC800E_TXD_Pin GPIO_PIN_7
#define EC800E_TXD_GPIO_Port GPIOC
#define SDIO_D0_Pin GPIO_PIN_8
#define SDIO_D0_GPIO_Port GPIOC
#define SDIO_D1_Pin GPIO_PIN_9
#define SDIO_D1_GPIO_Port GPIOC
#define bluetooth_AT_Pin GPIO_PIN_10
#define bluetooth_AT_GPIO_Port GPIOA
#define SDIO_D2_Pin GPIO_PIN_10
#define SDIO_D2_GPIO_Port GPIOC
#define SDIO_D3_Pin GPIO_PIN_11
#define SDIO_D3_GPIO_Port GPIOC
#define SDIO_CK_Pin GPIO_PIN_12
#define SDIO_CK_GPIO_Port GPIOC
#define LED_GREEN_Pin GPIO_PIN_0
#define LED_GREEN_GPIO_Port GPIOD
#define LED_RED_Pin GPIO_PIN_1
#define LED_RED_GPIO_Port GPIOD
#define SDIO_CMD_Pin GPIO_PIN_2
#define SDIO_CMD_GPIO_Port GPIOD

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
