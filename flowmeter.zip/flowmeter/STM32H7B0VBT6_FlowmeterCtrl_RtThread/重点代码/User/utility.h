#ifndef __LED_H
#define __LED_H

#include "stm32h7xx_hal.h"
#include "rtthread.h"
#include "main.h"
#include <stdbool.h>
//#include <stdio.h>
//#include <stdlib.h>
//#include <string.h>

typedef	bool	BIT;
extern 	uint8_t flag;
extern 	uint16_t jishuzhi;
extern 	uint16_t	ADC_delay_ms;

#define	COUNT_OF(n)			sizeof(n)/sizeof(n[0])



#endif

