#ifndef _INCLUDES_H_
#define _INCLUDES_H_


/************************ͷ�ļ�****************************/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "stm32h7xx_hal.h"
#include "arm_math.h"
#include "cJSON.h"

#include "rtthread.h"
#include "tim.h"
#include "spi.h"
#include "adc.h"
#include "utility.h"
#include "rtc.h"
#include "usart.h"
#include "sdmmc.h"
#include "fatfs.h"

#include "drv_gpio_key.h"
#include "drv_uart_bluetooth.h"
#include "drv_gpio_led.h"
#include "drv_spi_ssd1306.h"
#include "bmp.h"
#include "oledfont.h"
#include "drv_uart.h"
#include "drv_adc.h"
#include "drv_gnss_config.h"
#include "drv_gnss_l76x.h"
#include "drv_pwm_m.h"
#include "drv_fats_sd.h"
#include "drv_uart_gprs.h"
#include "ec800e_mqtt.h"
#include "process_data.h"

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif
#define SOUND_SPEED 1480  // ���� (��/��)

extern 	uint8_t adc_dma_end_flag;
extern 	uint8_t pwm_transcomp_flag;
extern 	uint8_t uart4_get_flag;

extern	_GNSS 			GPS;
extern	RTC_TimeTypeDef GetTime;
extern	RTC_DateTypeDef GetData;
extern	ParsedData 		data;

extern 	uint8_t delay_send_flag;
extern 	uint8_t delay_get_flag;

extern 	uint8_t	order_of_m;
extern 	uint8_t	multiple;
extern	float 	corr_max_lags_ms;
extern	float 	distance;
extern 	uint8_t	switch_sendget_flag;
extern 	uint8_t	gprs_send_flag;
extern 	uint8_t	rtc_update_flag;

#endif

