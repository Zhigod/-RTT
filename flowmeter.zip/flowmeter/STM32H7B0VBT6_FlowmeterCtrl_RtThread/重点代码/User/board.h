#ifndef _BOARD_H_
#define _BOARD_H_

#include "stm32h7xx_hal.h"

#endif

