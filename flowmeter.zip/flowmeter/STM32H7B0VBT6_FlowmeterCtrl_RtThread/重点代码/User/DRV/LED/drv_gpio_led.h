#ifndef __DRV_LED__H__
#define __DRV_LED__H__

#include "utility.h"


void Toggle_LED(GPIO_TypeDef* GPIOx,rt_uint16_t GPIO_Pin);


#endif

