#include "includes.h"

/* -------------------------------- begin  -------------------------------- */
/**
  * @Name    Toggle_LED
  * @brief   led��ƽ��ת����
  * @param   parameter: [����/��] 
  * @retval  None
  * @author  �����
  * @Data    2024-05-25
 **/
/* -------------------------------- end -------------------------------- */

void Toggle_LED(GPIO_TypeDef* GPIOx,rt_uint16_t GPIO_Pin)
{
    /* ��ȡ��ǰ LED ���ŵ�״̬ */
    GPIO_PinState pinState = HAL_GPIO_ReadPin(GPIOx, GPIO_Pin);

    /* ��ת LED ���ŵ�״̬ */
    if (pinState == GPIO_PIN_SET)
    {
        HAL_GPIO_WritePin(GPIOx, GPIO_Pin, GPIO_PIN_RESET);
    }
    else
    {
        HAL_GPIO_WritePin(GPIOx, GPIO_Pin, GPIO_PIN_SET);
    }
}

//	HAL_GPIO_WritePin(LED_RED_GPIO_Port, LED_RED_Pin, GPIO_PIN_SET);


