#ifndef __BULETOOTH_H
#define __BULETOOTH_H

#include "utility.h"

uint8_t Bluetooth_Send_CMD(char* cmd,uint8_t clean);






#endif

