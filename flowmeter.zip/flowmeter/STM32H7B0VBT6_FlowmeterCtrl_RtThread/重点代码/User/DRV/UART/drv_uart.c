#include "includes.h"

UART_HandleTypeDef_Custom huart2_custom;
UART_HandleTypeDef_Custom huart3_custom;
UART_HandleTypeDef_Custom huart4_custom;
UART_HandleTypeDef_Custom_1000 huart6_custom;


/* -------------------------------- begin  -------------------------------- */
/**
  * @Name    Uart4_SendString
  * @brief   �������ڷ����ַ�������
  * @param   None
  * @retval  None
  * @author  �����
  * @Data    2024-05-27
 **/
/* -------------------------------- end -------------------------------- */

void Uart4_SendString(uint8_t *str)
{
	unsigned int k=0;
  do 
  {
      HAL_UART_Transmit(&huart4,(uint8_t *)(str + k) ,1,1000);
      k++;
  } while(*(str + k)!='\0');
  
}

/* -------------------------------- begin  -------------------------------- */
/**
  * @Name    Uart2_SendString
  * @brief   ����2 232 �����ַ�������
  * @param   None
  * @retval  None
  * @author  �����
  * @Data    2024-05-27
 **/
/* -------------------------------- end -------------------------------- */

void Uart2_SendString(uint8_t *str)
{
	unsigned int k=0;
  do 
  {
      HAL_UART_Transmit(&huart2,(uint8_t *)(str + k) ,1,1000);
      k++;
  } while(*(str + k)!='\0');
  
}

/* -------------------------------- begin  -------------------------------- */
/**
  * @Name    Uart3_SendString
  * @brief   ����3 GNSS�����ַ�������
  * @param   None
  * @retval  None
  * @author  �����
  * @Data    2024-06-26
 **/
/* -------------------------------- end -------------------------------- */

void Uart3_SendString(uint8_t *str)
{
	unsigned int k=0;
  do 
  {
      HAL_UART_Transmit(&huart3,(uint8_t *)(str + k) ,1,1000);
      k++;
  } while(*(str + k)!='\0');
  
}


/* -------------------------------- begin  -------------------------------- */
/**
  * @Name    Uart6_SendString
  * @brief   ����6 GNSS�����ַ�������
  * @param   None
  * @retval  None
  * @author  �����
  * @Data    2024-06-26
 **/
/* -------------------------------- end -------------------------------- */

void Uart6_SendString(uint8_t *str)
{
	unsigned int k=0;
	do 
	{
	 HAL_UART_Transmit(&huart6,(uint8_t *)(str + k) ,1,1000);
	 k++;
	} while(*(str + k)!='\0');
  
}




			// ���� "AT" �� UART4  ����״��̬��ƽATָ��ߵ�ƽ͸����δ����Ĭ��ATָ��ģʽ
			//HAL_GPIO_WritePin(bluetooth_AT_GPIO_Port, bluetooth_AT_Pin, GPIO_PIN_RESET);	//����
