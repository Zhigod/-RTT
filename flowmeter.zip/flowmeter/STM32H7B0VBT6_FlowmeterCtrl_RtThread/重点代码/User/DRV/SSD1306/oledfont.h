#ifndef __OLEDFONT_H
#define __OLEDFONT_H

extern const unsigned char asc2_0806[][6];
extern const unsigned char asc2_1206[95][12];
extern const unsigned char asc2_1608[][16];  
extern const unsigned char asc2_2412[][36];  
extern const unsigned char Hzk1[][32];
extern const unsigned char Hzk2[][72];
extern const unsigned char Hzk3[][128];
extern const unsigned char Hzk4[][512];



#endif

