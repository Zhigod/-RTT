#ifndef __BMP_H
#define __BMP_H

extern unsigned char BMP1[];

#endif


