#include "includes.h"


/* -------------------------------- begin  ----------------------------- */
/**
  * @Name    transform_array
  * @brief   ��Ƶ����
  * @param   ����m���У����m���У�m���и�������Ƶ����
  * @retval  None
  * @author  �����
  * @Data    2024-06-15
 **/
/* -------------------------------- end -------------------------------- */
void transform_array(uint8_t* input_array, uint32_t* output_array,uint16_t number_of_m,uint8_t time) {
    uint16_t j = 0;

    for (uint16_t i = 0; i <= number_of_m; i++) {
        if (input_array[i] == 1) {
			for(uint16_t k = 0;k < time; k++)
			{
				output_array[j++] = 133;
			}
        } else if (input_array[i] == 0) {
			for(uint16_t k = 0;k < time; k++)
			{
				output_array[j++] = 0;
			}
        }
    }
}

/* -------------------------------- begin  ----------------------------- */
/**
  * @Name    remove_last_133
  * @brief   ȥ������һ��133����ֹbmp������� 
  * @param   ��Ƶ���m���У�m���д�С
  * @retval  None
  * @author  �����
  * @Data    2024-06-15
 **/
/* -------------------------------- end -------------------------------- */
void remove_last_133(uint32_t* array, int size) {
    int result_index = 0; // ��¼������������

    for (int i = 0; i < size; i++) {
        if (array[i] == 133 && (i == size - 1 || array[i + 1] != 133)) // �����ǰԪ���� 133 ����һ��Ԫ�ز��� 133
		{
			if(i != 0)				//���ǵ�һ��
			{
				if(array[i - 1] != 0) //֮ǰһ����Ϊ0���ų���Ƶ1����
				{
					continue; // ������ǰ 133
				}
			}
        }
	
        // ���Ƶ�ǰԪ�ص����������
        array[result_index++] = array[i];
    }
}


/* -------------------------------- begin  ----------------------------- */
/**
  * @Name    Select_m_send
  * @brief   ��ѡm���в����ͺ���
  * @param   m���н�����һ����Ԫ��Ӧ�Ĳ�������
  * @retval  None
  * @author  �����
  * @Data    2024-06-15
 **/
/* -------------------------------- end -------------------------------- */
const uint8_t m3_sequence[8]	= {0,0,1,0,1,1,1};
const uint8_t m4_sequence[15] 	= {0,0,0,1,0,0,1,1,0,1,0,1,1,1,1};
const uint8_t m5_sequence[31] 	= {0,0,0,0,1,0,0,1,0,1,1,0,0,1,1,1,1,1,0,0,0,1,1,0,1,1,1,0,1,0,1};
const uint8_t m6_sequence[63] 	= {0,0,0,0,0,1,0,0,0,0,1,1,0,0,0,1,0,1,0,0,1,1,1,1,0,1,0,0,0,1,1,1,0,0,1,0,0,1,0,1,1,0,1,1,1,0,1,1,0,0,1,1,0,1,0,1,0,1,1,1,1,1,1};
const uint8_t m7_sequence[127] 	= {0,0,0,0,0,0,1,0,0,0,0,0,1,1,0,0,0,0,1,0,1,0,0,0,1,1,1,1,0,0,1,0,0,0,1,0,1,1,0,0,1,1,1,0,1,0,1,0,0,1,1,1,1,1,0,1,0,0,0,0,1,1,1,0,
	0,0,1,0,0,1,0,0,1,1,0,1,1,0,1,0,1,1,0,1,1,1,1,0,1,1,0,0,0,1,1,0,1,0,0,1,0,1,1,1,0,1,1,1,0,0,1,1,0,0,1,0,1,0,1,0,1,1,1,1,1,1,1};
const uint8_t m8_sequence[255] 	= {0,0,0,0,0,0,0,1,0,0,0,1,1,1,0,0,0,1,0,0,1,0,1,1,1,0,0,0,0,0,0,1,1,0,0,1,0,0,1,0,0,1,1,0,1,1,1,0,0,1,0,0,0,0,0,1,0,1,0,1,1,0,1,1,
	0,1,0,1,1,0,0,1,0,1,1,0,0,0,0,1,1,1,1,1,0,1,1,0,1,1,1,1,0,1,0,1,1,1,0,1,0,0,0,1,0,0,0,0,1,1,0,1,1,0,0,0,1,1,1,1,0,0,1,1,1,0,0,1,1,0,0,0,1,0,1,1,0,1,0,0,1,0,0,
	0,1,0,1,0,0,1,0,1,0,1,0,0,1,1,1,0,1,1,1,0,1,1,0,0,1,1,1,1,0,1,1,1,1,1,1,0,1,0,0,1,1,0,0,1,1,0,1,0,1,0,0,0,1,1,0,0,0,0,0,1,1,1,0,1,0,1,0,1,0,1,1,1,1,1,0,0,1,0,
	1,0,0,0,0,1,0,0,1,1,1,1,1,1,1,1,0,0,0,0,1,0,1,1,1,1,0,0,0,1,1,0,1};
const uint8_t m9_sequence[511] 	= {0,0,0,0,0,0,0,0,1,0,0,0,0,1,0,0,0,1,1,0,0,0,0,1,0,0,1,1,1,0,0,1,0,1,0,1,0,1,1,0,0,0,0,1,1,0,1,1,1,1,0,1,0,0,1,1,0,1,1,1,0,0,1,0,
	0,0,1,0,1,0,0,0,0,1,0,1,0,1,1,0,1,0,0,1,1,1,1,1,1,0,1,1,0,0,1,0,0,1,0,0,1,0,1,1,0,1,1,1,1,1,1,0,0,1,0,0,1,1,0,1,0,1,0,0,1,1,0,0,1,1,0,0,0,0,0,0,0,1,1,0,0,0,1,
	1,0,0,1,0,1,0,0,0,1,1,0,1,0,0,1,0,1,1,1,1,1,1,1,0,1,0,0,0,1,0,1,1,0,0,0,1,1,1,0,1,0,1,1,0,0,1,0,1,1,0,0,1,1,1,1,0,0,0,1,1,1,1,1,0,1,1,1,0,1,0,0,0,0,0,1,1,0,1,
	0,1,1,0,1,1,0,1,1,1,0,1,1,0,0,0,0,0,1,0,1,1,0,1,0,1,1,1,1,1,0,1,0,1,0,1,0,1,0,0,0,0,0,0,1,0,1,0,0,1,0,1,0,1,1,1,1,0,0,1,0,1,1,1,0,1,1,1,0,0,0,0,0,0,1,1,1,0,0,
	1,1,1,0,1,0,0,1,0,0,1,1,1,1,0,1,0,1,1,1,0,1,0,1,0,0,0,1,0,0,1,0,0,0,0,1,1,0,0,1,1,1,0,0,0,0,1,0,1,1,1,1,0,1,1,0,1,1,0,0,1,1,0,1,0,0,0,0,1,1,1,0,1,1,1,1,0,0,0,
	0,1,1,1,1,1,1,1,1,1,0,0,0,0,0,1,1,1,1,0,1,1,1,1,1,0,0,0,1,0,1,1,1,0,0,1,1,0,0,1,0,0,0,0,0,1,0,0,1,0,1,0,0,1,1,1,0,1,1,0,1,0,0,0,1,1,1,1,0,0,1,1,1,1,1,0,0,1,1,
	0,1,1,0,0,0,1,0,1,0,1,0,0,1,0,0,0,1,1,1,0,0,0,1,1,0,1,1,0,1,0,1,0,1,1,1,0,0,0,1,0,0,1,1,0,0,0,1,0,0,0,1};
const uint8_t m10_sequence[1023] ={0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,1,0,0,1,0,0,0,1,0,0,0,0,0,1,1,0,0,1,0,0,1,1,0,1,0,0,0,0,1,0,0,1,0,1,0,1,0,0,0,0,1,1,1,1,0,1,0,1,
	1,1,0,1,0,1,1,0,1,1,0,1,1,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,1,1,0,1,1,0,0,1,1,0,0,0,0,1,0,1,0,1,1,0,1,0,1,1,1,0,0,0,1,1,0,1,1,1,1,1,1,0,0,0,1,0,0,0,1,1,1,1,0,0,1,
	1,1,1,0,1,1,0,1,1,0,1,0,0,0,0,0,0,0,1,0,1,0,0,0,0,1,0,1,1,0,1,0,1,0,1,0,0,0,1,1,1,1,1,0,1,1,1,1,0,0,1,0,0,1,0,1,1,0,0,0,0,0,1,0,0,1,1,0,0,1,0,0,0,1,0,1,0,0,0,
	1,1,0,1,1,0,1,1,1,0,0,0,0,0,0,1,1,1,1,0,0,0,1,1,1,0,1,1,1,1,1,1,1,0,0,1,0,0,0,0,1,1,0,0,0,1,0,1,1,0,1,1,1,0,1,0,0,0,0,1,1,0,1,0,1,0,1,1,0,0,1,1,1,1,0,0,1,0,1,
	1,0,1,1,0,0,1,0,0,0,0,0,1,0,0,0,1,0,0,1,0,0,1,1,0,0,0,0,0,0,1,0,1,1,0,0,0,1,0,1,0,0,1,1,1,0,1,1,0,0,1,1,1,0,0,0,1,0,1,1,1,1,1,1,0,1,0,1,0,0,0,1,0,1,1,1,0,1,1,
	0,1,0,1,1,0,0,0,0,1,1,0,0,1,1,0,1,1,0,1,0,1,0,0,0,0,0,1,1,1,0,1,0,0,1,1,1,1,0,1,0,0,1,1,0,1,0,1,0,0,1,0,0,1,1,1,0,0,0,0,0,1,1,1,1,1,0,0,1,1,1,0,0,1,1,0,1,1,1,
	1,0,1,0,0,0,1,0,1,0,1,0,1,1,0,1,1,1,1,1,0,0,0,0,1,0,0,1,1,1,0,1,0,0,0,1,1,1,0,1,0,1,1,1,1,1,0,1,1,0,1,0,0,1,0,0,0,0,1,0,0,0,0,1,0,1,0,0,1,0,1,0,1,1,0,0,0,1,1,
	1,0,0,1,1,1,1,1,1,1,0,1,1,0,0,0,0,1,0,0,0,1,1,0,1,0,0,1,1,1,0,0,1,0,0,1,1,1,1,0,0,0,0,1,1,0,1,1,1,0,1,1,0,0,0,1,1,0,0,0,1,1,1,1,0,1,1,1,1,1,0,1,0,0,1,0,0,1,0,
	1,0,0,0,0,0,0,1,1,0,1,0,0,0,1,1,0,0,1,0,1,1,1,0,1,0,0,1,0,1,1,0,1,0,0,0,1,0,0,0,1,0,1,1,0,0,1,1,0,1,0,0,1,0,1,0,0,1,0,0,0,1,1,0,0,0,0,1,1,1,0,1,1,0,1,1,1,1,0,
	0,0,0,0,1,0,1,1,1,0,0,1,0,1,0,1,1,1,0,0,1,1,1,0,1,1,1,0,1,1,1,0,0,1,1,0,0,1,1,1,0,1,0,1,0,1,1,1,0,1,1,1,1,0,1,1,0,0,1,0,1,0,0,0,1,0,0,1,1,0,1,1,0,0,0,1,0,0,0,
	0,1,1,1,0,0,1,0,1,1,1,1,1,0,0,1,0,1,0,0,1,1,0,0,1,1,0,0,1,0,1,0,1,0,1,0,0,1,1,1,1,1,1,0,0,1,1,0,0,0,1,1,0,1,0,1,1,1,1,0,0,1,1,0,1,0,1,1,0,1,0,0,1,1,0,0,0,1,0,
	0,1,0,1,1,1,0,0,0,0,1,0,1,1,1,1,0,1,0,1,0,1,0,1,0,1,1,1,1,1,1,1,1,0,1,0,0,0,0,0,1,0,1,0,1,0,0,1,0,1,1,1,1,0,0,0,1,0,1,0,1,1,1,1,0,1,1,1,0,1,0,1,0,0,1,1,0,1,1,
	1,0,0,1,0,0,0,1,1,1,0,0,0,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,1,1,1,0,0,0,0,1,1,1,1,1,1,0,1,1,1,0,0,0,1,0,0,1,1,1,1,1,0,0,0,1,1,0,0,1,1,1,1,1,0,1,0,1,1,0,0,1,0,
	1,1,0,0,1,0,0,1,0,0,1};

uint8_t		m_sequence[1023];
uint32_t 	m_Width[15000];
uint32_t 	Pulse_Width[15000];	//��෢10��*10 10240������
uint16_t 	number_of_m;
uint16_t	width_size;

void Select_m_send(uint8_t num,uint8_t time)
{
	if(num == 0 || time == 0)
	{
		printf("m�������ݴ���");
		return;
	}
	
	switch(num)
    {
		case 3:
			memcpy(m_sequence, m3_sequence, 8 * sizeof(uint32_t));
			break;
		case 4:
			memcpy(m_sequence, m4_sequence, 15 * sizeof(uint32_t));
			break;
		case 5:
			memcpy(m_sequence, m5_sequence, 31 * sizeof(uint32_t));
			break;
		case 6:
			memcpy(m_sequence, m6_sequence, 63 * sizeof(uint32_t));
			break;
		case 7:
			memcpy(m_sequence, m7_sequence, 127 * sizeof(uint32_t));
			break;
		case 8:
			memcpy(m_sequence, m8_sequence, 255 * sizeof(uint32_t));
			break;
		case 9:
			memcpy(m_sequence, m9_sequence, 511 * sizeof(uint32_t));
			break;
		case 10:
			memcpy(m_sequence, m10_sequence, 1023 * sizeof(uint32_t));
			break;
		default:
			break;
	}
	
	number_of_m = (1 << num) -1;

	width_size = number_of_m * time;
	
	transform_array(m_sequence,m_Width,number_of_m,time); 			//��Ƶ
	remove_last_133(m_Width,COUNT_OF(m_Width));						//ȥ������133
	for(int i = 0;i < width_size; i++)
	{
		Pulse_Width[i] = 66;
	}
	HAL_TIM_PWM_Start_DMA(&htim5, TIM_CHANNEL_2, (uint32_t*)Pulse_Width, width_size + 1); 	//����PWM
	HAL_TIM_PWM_Start_DMA(&htim5, TIM_CHANNEL_4, (uint32_t*)m_Width, width_size + 1); 		//����m����

}
void Select_m_send_2(uint8_t num,uint8_t time)
{
	if(num == 0 || time == 0)
	{
		printf("m�������ݴ���");
		return;
	}
	
	switch(num)
    {
		case 3:
			memcpy(m_sequence, m3_sequence, 8 * sizeof(uint32_t));
			break;
		case 4:
			memcpy(m_sequence, m4_sequence, 15 * sizeof(uint32_t));
			break;
		case 5:
			memcpy(m_sequence, m5_sequence, 31 * sizeof(uint32_t));
			break;
		case 6:
			memcpy(m_sequence, m6_sequence, 63 * sizeof(uint32_t));
			break;
		case 7:
			memcpy(m_sequence, m7_sequence, 127 * sizeof(uint32_t));
			break;
		case 8:
			memcpy(m_sequence, m8_sequence, 255 * sizeof(uint32_t));
			break;
		case 9:
			memcpy(m_sequence, m9_sequence, 511 * sizeof(uint32_t));
			break;
		case 10:
			memcpy(m_sequence, m10_sequence, 1023 * sizeof(uint32_t));
			break;
		default:
			break;
	}
	
	number_of_m = (1 << num) -1;

	width_size = number_of_m * time;
	
	transform_array(m_sequence,m_Width,number_of_m,time); 			//��Ƶ
	remove_last_133(m_Width,COUNT_OF(m_Width));						//ȥ������133
	for(int i = 0;i < width_size; i++)
	{
		Pulse_Width[i] = 66;
	}

}


/* -------------------------------- begin  ----------------------------- */
/**
  * @Name    StartTimerDelay
  * @brief   ������ʱ����ʱ
  * @param   
  * @retval  None
  * @author  �����
  * @Data    2024-08-08
 **/
/* -------------------------------- end -------------------------------- */
void StartTimerDelay(uint32_t delay_ms)
{
    // ���ö�ʱ������װ��ֵ��ʵ��ָ����ʱ
    __HAL_TIM_SET_AUTORELOAD(&htim2, delay_ms - 1);
    
    // ���������ֵ
    __HAL_TIM_SET_COUNTER(&htim2, 0);
    
    // ������ʱ���ж�
    HAL_TIM_Base_Start_IT(&htim2);
}







#if 0
void Select_m_send(uint8_t num,uint8_t time)
{
	uint32_t 	number_of_m = (1 << num) -1;
	uint32_t	width_size = 0;
	width_size = number_of_m * time;
	switch(num)
    {
	case 3:
		memcpy(m_sequence, m3_sequence, 8 * sizeof(uint32_t));
		break;

	case 4:
m_sequence = m10_sequence;
		transform_array(m4_sequence,m_Width,number_of_m,time); 			//��Ƶ
		remove_last_133(m_Width,COUNT_OF(m_Width));						//ȥ������133,3������3Ҫ(������һ������)��4Ҫ(ͷû����)��5Ҫ(ͷû����)
		for(int i = 0;i < width_size; i++)
		{
			Pulse_Width[i] = 66;
		}
		HAL_TIM_PWM_Start_DMA(&htim5, TIM_CHANNEL_2, (uint32_t*)Pulse_Width, width_size + 1); 	//����PWM
		HAL_TIM_PWM_Start_DMA(&htim5, TIM_CHANNEL_4, (uint32_t*)m_Width, width_size + 1); 		//����m����

		break;

	case 5:
m_sequence = m10_sequence;
		transform_array(m5_sequence,m_Width,number_of_m,time); 			//��Ƶ
		remove_last_133(m_Width,COUNT_OF(m_Width));						//ȥ������133��ֻ�ܷ�3�ף���4�״򲻿�SD��,����̫���ˣ�����һ��һ��
		for(int i = 0;i < width_size; i++)
		{
			Pulse_Width[i] = 66;
		}
		HAL_TIM_PWM_Start_DMA(&htim5, TIM_CHANNEL_2, (uint32_t*)Pulse_Width, width_size + 1); 	//����PWM
		HAL_TIM_PWM_Start_DMA(&htim5, TIM_CHANNEL_4, (uint32_t*)m_Width, width_size + 1); 		//����m����
		
		break;

	case 6:
m_sequence = m10_sequence;
		transform_array(m6_sequence,m_Width,number_of_m,time); 			//��Ƶ
		remove_last_133(m_Width,COUNT_OF(m_Width));						//ȥ������133��ֻ�ܷ�3�ף���4�״򲻿�SD��,����̫���ˣ�����һ��һ��
		for(int i = 0;i < width_size; i++)
		{
			Pulse_Width[i] = 66;
		}
		HAL_TIM_PWM_Start_DMA(&htim5, TIM_CHANNEL_2, (uint32_t*)Pulse_Width, width_size + 1); 	//����PWM
		HAL_TIM_PWM_Start_DMA(&htim5, TIM_CHANNEL_4, (uint32_t*)m_Width, width_size + 1); 		//����m����
		
		break;
		
	case 7:
m_sequence = m10_sequence;
		transform_array(m7_sequence,m_Width,number_of_m,time); 			//��Ƶ
		remove_last_133(m_Width,COUNT_OF(m_Width));						//ȥ������133��ֻ�ܷ�3�ף���4�״򲻿�SD��,����̫���ˣ�����һ��һ��
		for(int i = 0;i < width_size; i++)
		{
			Pulse_Width[i] = 66;
		}
		HAL_TIM_PWM_Start_DMA(&htim5, TIM_CHANNEL_2, (uint32_t*)Pulse_Width, width_size + 1); 	//����PWM
		HAL_TIM_PWM_Start_DMA(&htim5, TIM_CHANNEL_4, (uint32_t*)m_Width, width_size + 1); 		//����m����
		
		break;
	
	case 8:
m_sequence = m10_sequence;
		transform_array(m8_sequence,m_Width,number_of_m,time); 			//��Ƶ
		remove_last_133(m_Width,COUNT_OF(m_Width));						//ȥ������133��ֻ�ܷ�3�ף���4�״򲻿�SD��,����̫���ˣ�����һ��һ��
		for(int i = 0;i < width_size; i++)
		{
			Pulse_Width[i] = 66;
		}
		HAL_TIM_PWM_Start_DMA(&htim5, TIM_CHANNEL_2, (uint32_t*)Pulse_Width, width_size + 1); 	//����PWM
		HAL_TIM_PWM_Start_DMA(&htim5, TIM_CHANNEL_4, (uint32_t*)m_Width, width_size + 1); 		//����m����
		
		break;
		
	case 9:
m_sequence = m10_sequence;
		transform_array(m9_sequence,m_Width,number_of_m,time); 			//��Ƶ
		remove_last_133(m_Width,COUNT_OF(m_Width));						//ȥ������133��ֻ�ܷ�3�ף���4�״򲻿�SD��,����̫���ˣ�����һ��һ��
		for(int i = 0;i < width_size; i++)
		{
			Pulse_Width[i] = 66;
		}
		HAL_TIM_PWM_Start_DMA(&htim5, TIM_CHANNEL_2, (uint32_t*)Pulse_Width, width_size + 1); 	//����PWM
		HAL_TIM_PWM_Start_DMA(&htim5, TIM_CHANNEL_4, (uint32_t*)m_Width, width_size + 1); 		//����m����
		
		break;
		
	case 10:
m_sequence = m10_sequence;
		transform_array(m10_sequence,m_Width,number_of_m,time); 			//��Ƶ
		remove_last_133(m_Width,COUNT_OF(m_Width));						//ȥ������133��ֻ�ܷ�3�ף���4�״򲻿�SD��,����̫���ˣ�����һ��һ��
		for(int i = 0;i < width_size; i++)
		{
			Pulse_Width[i] = 66;
		}
		HAL_TIM_PWM_Start_DMA(&htim5, TIM_CHANNEL_2, (uint32_t*)Pulse_Width, width_size + 1); 	//����PWM
		HAL_TIM_PWM_Start_DMA(&htim5, TIM_CHANNEL_4, (uint32_t*)m_Width, width_size + 1); 		//����m����
		
		break;
	
	default:
        break;
	
		transform_array(m_sequence,m_Width,number_of_m,time); 			//��Ƶ
		remove_last_133(m_Width,COUNT_OF(m_Width));						//ȥ������133,3������3Ҫ��4Ҫ��5Ҫ
		for(int i = 0;i < width_size; i++)
		{
			Pulse_Width[i] = 66;
		}
		HAL_TIM_PWM_Start_DMA(&htim5, TIM_CHANNEL_2, (uint32_t*)Pulse_Width, width_size + 1); 	//����PWM
		HAL_TIM_PWM_Start_DMA(&htim5, TIM_CHANNEL_4, (uint32_t*)m_Width, width_size + 1); 		//����m����

	}

}
#endif
