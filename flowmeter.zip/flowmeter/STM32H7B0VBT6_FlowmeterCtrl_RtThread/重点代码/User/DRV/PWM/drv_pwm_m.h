#ifndef		__DRV_PWM_M__H__
#define		__DRV_PWM_M__H__

#include "includes.h"
#include "utility.h"

//const uint32_t* transform_array(const uint32_t* input_array);

//uint32_t* transform_array(uint32_t* input_array);
void transform_array(uint8_t* input_array, uint32_t* output_array,uint16_t number_of_m,uint8_t time);
void remove_last_133(uint32_t* array, int size);
void Select_m_send(uint8_t num,uint8_t time);
void Select_m_send_2(uint8_t num,uint8_t time);

void send_m_start(int result);
void StartTimerDelay(uint32_t delay_ms);

extern	uint16_t 	number_of_m;
extern 	uint16_t	width_size;
extern 	uint8_t		m_sequence[1023];

#endif
