#include "includes.h"





void cross_correlation(float* low_pass, int low_pass_length, int8_t* m_Width, int m_Width_length, float* result) {
    int n, k;
    for (n = 0; n < low_pass_length; n++) {
        result[n] = 0;
        for (k = 0; k < m_Width_length; k++) {
            if ((n + k) < low_pass_length) {
                result[n] += low_pass[n + k] * m_Width[k];
            }
        }
    }
}






