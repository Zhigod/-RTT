#ifndef __PROCESS_DATA_H_
#define __PROCESS_DATA_H_

#include "utility.h"

void cross_correlation(float* low_pass, int low_pass_length, int8_t* m_Width, int m_Width_length, float* result);

#endif
