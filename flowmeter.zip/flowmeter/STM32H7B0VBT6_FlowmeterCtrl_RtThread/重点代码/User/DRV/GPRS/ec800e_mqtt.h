#ifndef __EC800E_MQTT_H_
#define __EC800E_MQTT_H_

// �������ݽṹ����������������
typedef struct {
	char 	deviceName[50];
    int 	order_of_m;
    int 	multiple;
    char 	latitude[20];
    char	longitude[20];
    double 	corr_max_lags_ms;
    int 	send_interval;
    double 	distance;
    int 	test_switch;
	uint8_t	switch_sendget_flag_1;
	uint8_t	switch_sendget_flag_2;
	uint8_t	refresh;
} ParsedData;

int module_MQTT(void);
int gprs_send_date(void);
int module_data(void);
int extract_int_value(const char *json_data, const char *key);
void parse_json(const char *json_str, ParsedData  *data);

extern	uint16_t 	send_interval;
extern	uint8_t		Send_interval_update_flag;
extern	uint8_t		test_switch;

#endif


