#ifndef __FLASH_H_
#define __FLASH_H_

//#define FLASH_USER_START_ADDR   ADDR_FLASH_SECTOR_127   /* Start @ of user Flash area */
//#define FLASH_USER_END_ADDR     (ADDR_FLASH_SECTOR_127 + FLASH_SECTOR_SIZE - 1) /* End @ of user Flash area */
//#define FLASH_FLAG_ADDRESS      FLASH_USER_START_ADDR   /* Address to store the flag */

//void Flash_EraseSector(uint32_t SectorAddress);
//void Flash_Write(uint32_t Address, uint32_t Data);
//uint32_t Flash_Read(uint32_t Address);


#endif

