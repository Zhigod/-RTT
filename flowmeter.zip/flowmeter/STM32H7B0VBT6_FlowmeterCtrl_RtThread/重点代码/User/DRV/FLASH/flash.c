#include "includes.h"

//void Flash_EraseSector(uint32_t SectorAddress) {
//    HAL_FLASH_Unlock();

//    FLASH_EraseInitTypeDef EraseInitStruct;
//    uint32_t SectorError = 0;

//    EraseInitStruct.TypeErase = FLASH_TYPEERASE_SECTORS;
//    EraseInitStruct.VoltageRange = FLASH_VOLTAGE_RANGE_3;
//    EraseInitStruct.Sector = SectorAddress;
//    EraseInitStruct.NbSectors = 1;

//    if (HAL_FLASHEx_Erase(&EraseInitStruct, &SectorError) != HAL_OK) {
//        // Handle error
//    }

//    HAL_FLASH_Lock();
//}

//void Flash_Write(uint32_t Address, uint32_t Data) {
//    HAL_FLASH_Unlock();

//    if (HAL_FLASH_Program(FLASH_TYPEPROGRAM_FLASHWORD, Address, Data) != HAL_OK) {
//        // Handle error
//    }

//    HAL_FLASH_Lock();
//}

//uint32_t Flash_Read(uint32_t Address) {
//    return *(uint32_t*)Address;
//}


