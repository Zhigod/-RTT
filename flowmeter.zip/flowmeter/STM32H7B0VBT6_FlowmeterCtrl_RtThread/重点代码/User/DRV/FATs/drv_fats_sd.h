#ifndef		__DRV_FATS_SD__H__
#define		__DRV_FATS_SD__H__

#include "includes.h"

FRESULT moveToColumn(FIL* fp,int column);




#endif


