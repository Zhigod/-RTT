#ifndef __DRV_GNSS_L76X_H_
#define __DRV_GNSS_L76X_H_

#include "utility.h"
#include "drv_gnss_config.h"


#if 0

#define BUFFSIZE 1600

// Startup mode
#define HOT_START       "$PMTK101"
#define WARM_START      "$PMTK102"
#define FULL_COLD_START "$PMTK104"

// Standby mode -- Exit requires high level trigger
#define SET_PERPETUAL_STANDBY_MODE      "$PMTK161"

#define SET_PERIODIC_MODE               "$PMTK225"
#define SET_NORMAL_MODE                 "$PMTK225,0"
#define SET_PERIODIC_BACKUP_MODE        "$PMTK225,1,1000,2000"
#define SET_PERIODIC_STANDBY_MODE       "$PMTK225,2,1000,2000"
#define SET_PERPETUAL_BACKUP_MODE       "$PMTK225,4"
#define SET_ALWAYSLOCATE_STANDBY_MODE   "$PMTK225,8"
#define SET_ALWAYSLOCATE_BACKUP_MODE    "$PMTK225,9"

// Set the message interval,100ms~10000ms
#define SET_POS_FIX         "$PMTK220"
#define SET_POS_FIX_100MS   "$PMTK220,100"
#define SET_POS_FIX_200MS   "$PMTK220,200"
#define SET_POS_FIX_400MS   "$PMTK220,400"
#define SET_POS_FIX_800MS   "$PMTK220,800"
#define SET_POS_FIX_1S      "$PMTK220,1000"
#define SET_POS_FIX_2S      "$PMTK220,2000"
#define SET_POS_FIX_4S      "$PMTK220,4000"
#define SET_POS_FIX_8S      "$PMTK220,8000"
#define SET_POS_FIX_10S     "$PMTK220,10000"

// Switching time output
#define SET_SYNC_PPS_NMEA_OFF   "$PMTK255,0"
#define SET_SYNC_PPS_NMEA_ON    "$PMTK255,1"

// Baud rate
#define SET_NMEA_BAUDRATE           "$PMTK251"
#define SET_NMEA_BAUDRATE_115200    "$PMTK251,115200"
#define SET_NMEA_BAUDRATE_57600     "$PMTK251,57600"
#define SET_NMEA_BAUDRATE_38400     "$PMTK251,38400"
#define SET_NMEA_BAUDRATE_19200     "$PMTK251,19200"
#define SET_NMEA_BAUDRATE_14400     "$PMTK251,14400"
#define SET_NMEA_BAUDRATE_9600      "$PMTK251,9600"
#define SET_NMEA_BAUDRATE_4800      "$PMTK251,4800"

// To restore the system default setting
#define SET_REDUCTION               "$PMTK314,-1"

// Set NMEA sentence output frequencies 
#define SET_NMEA_OUTPUT "$PMTK314,0,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0"

#endif


#define COLD_START      "$PMTK103"


//�������鳤��
#define UTCTime_Length 11
#define latitude_Length 11
#define N_S_Length 2
#define longitude_Length 12
#define E_W_Length 2 

typedef struct {
	char GPS_Buffer[UART_BUFFER_SIZE];
	char UTCTime[UTCTime_Length];		//UTCʱ��
	int hours, minutes;					//ʱ��
    float seconds;						//��
	char latitude[latitude_Length];		//γ��
	double latitude_dou;
	char N_S[N_S_Length];				//N/S
	char longitude[longitude_Length];	//����
	double longitude_dou;
	char E_W[E_W_Length];				//E/W
	char date[7];  						//����
	int day, month, year;				//
	uint8_t isGetData;						//�Ƿ��ȡ��GPS����
	uint8_t isParseData;					//�Ƿ�������
	uint8_t isUsefull;						//��λ��Ϣ�Ƿ���Ч
} _GNSS;	//GNRMC �ṹ�����ڴ洢GPSģ�鷵�ص�RMC���Ƽ�����޶ȶ�λ��Ϣ�����ݡ�


void L76X_Send_Command(char *data);
void ANALYSIS_GNSS_DATA(_GNSS *GPS);
void convertUTCtoHMS(const char *utc_time, int *hours, int *minutes, float *seconds);
void convertToBeijingTime(int *hours, int *minutes, float *seconds);
HAL_StatusTypeDef rtc_set_time(uint8_t hour, uint8_t min, uint8_t sec, uint8_t ampm);
HAL_StatusTypeDef rtc_set_date(uint8_t year, uint8_t month, uint8_t date);
void parseDate(char *dateString, int *day, int *month, int *year);
void errorLog(int num);
double parseLatitude(const char *lat);
double parseLongitude(const char *lon);
void parseGPSCoordinates(_GNSS *GPS);



#endif

