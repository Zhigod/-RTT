#ifndef __DRV_GNSS_CONFIG_H_
#define __DRV_GNSS_CONFIG_H_

#include "utility.h"

#define UBYTE   uint8_t
#define UWORD   uint16_t
#define UDOUBLE uint32_t

/**
 * GPIO config
**/
#define DEV_FORCE_Pin GPIO_PIN_4
#define DEV_FORCE_GPIO_Port GPIOA
#define DEV_STANDBY_Pin GPIO_PIN_5
#define DEV_STANDBY_GPIO_Port GPIOA

/**
 * GPIO read and write
**/
#define DEV_Digital_Write(_pin, _value) HAL_GPIO_WritePin(_pin##_GPIO_Port, _pin##_Pin, _value == 0 ? GPIO_PIN_RESET : GPIO_PIN_SET)
#define DEV_Digital_Read(_pin) HAL_GPIO_ReadPin(_pin##_GPIO_Port, _pin##_Pin)

/**
 * delay x ms
**/
#define DEV_Delay_ms(__xms)    HAL_Delay(__xms)


/*-----------------------------------------------------------------------------*/
UBYTE DEV_Uart_ReceiveByte(void);
void DEV_Uart_SendByte(char data);
void DEV_Uart_SendString(char *data);
void DEV_Uart_ReceiveString(char *data, UWORD Num);

void DEV_Set_Baudrate(UDOUBLE Baudrate);

void DEV_Set_GPIOMode(UWORD Pin, UWORD mode);




#endif





