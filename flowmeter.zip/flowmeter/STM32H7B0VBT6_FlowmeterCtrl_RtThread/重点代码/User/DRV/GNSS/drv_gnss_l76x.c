#include "includes.h"

char const Temp[16] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};


/* -------------------------------- begin  -------------------------------- */
/**
  * @Name    errorLog
  * @brief   ����GNSS���ݱ�������
  * @param   None
  * @retval  None
  * @author  �����
  * @Data    2024-06-06
 **/
/* -------------------------------- end -------------------------------- */
void errorLog(int num)
{
	//while (1)
	//{
	  	printf("ERROR%d\r\n",num);
	//}
}

/* -------------------------------- begin  -------------------------------- */
/**
  * @Name    ANALYSIS_GNSS_DATA
  * @brief   ����GNSS���ݺ���
  * @param   None
  * @retval  None
  * @author  �����
  * @Data    2024-06-06
 **/
/* -------------------------------- end -------------------------------- */
void ANALYSIS_GNSS_DATA(_GNSS *GPS) 
{
	char *subString;
	char *subStringNext;
	uint8_t i = 0;
	char usefullBuffer[2]; 

	for (i = 0 ; i <= 9 ; i++)
	{
		if (i == 0)
		{
			if ((subString = strstr(GPS->GPS_Buffer, ",")) == NULL)	//���ַ����в��ҵ�һ������λ�ã�����subString
				errorLog(1);	//��������
		}
		else
		{
			subString++;
			if ((subStringNext = strstr(subString, ",")) != NULL)
			{
				switch(i)
				{
					case 1:
						memcpy(GPS->UTCTime, subString, subStringNext - subString);
						break;	//��ȡUTCʱ��
					case 2:
						memcpy(usefullBuffer, subString, subStringNext - subString);
						break;	//��ȡ��Ч���ݱ�־λ
					case 3:
						memcpy(GPS->latitude, subString, subStringNext - subString);
						break;	//��ȡγ����Ϣ
					case 4:
						memcpy(GPS->N_S, subString, subStringNext - subString);
						break;	//��ȡN/S
					case 5:
						memcpy(GPS->longitude, subString, subStringNext - subString);
						break;	//��ȡ������Ϣ
					case 6:
						memcpy(GPS->E_W, subString, subStringNext - subString);
						break;	//��ȡE/W
					case 9:
						memcpy(GPS->date, subString, subStringNext - subString);
						break;  // ��ȡ������Ϣ
					default:
						break;
				}

				subString = subStringNext;
				GPS->isParseData = 1;
			}
			else
			{
				errorLog(2);	//��������
			}
		}
	}
	
	if(usefullBuffer[0] == 'A')
	{
		convertUTCtoHMS(GPS->UTCTime, &GPS->hours, &GPS->minutes, &GPS->seconds); //ת��UTCʱ��
		convertToBeijingTime(&GPS->hours, &GPS->minutes, &GPS->seconds);		//ת������ʱ��
		parseDate(GPS->date, &GPS->day, &GPS->month, &GPS->year);				//ת��������
		parseGPSCoordinates(GPS);
	
		GPS->isUsefull = 1;
	}
	else if(usefullBuffer[0] == 'V')
		GPS->isUsefull = 0;


}

/* -------------------------------- begin  -------------------------------- */
/**
  * @Name    L76X_Send_Command
  * @brief   GNSS����ͺ�������L76X��������Զ�������룬data ������Ľ�β�ԡ�\0����β����������
  * @param   None
  * @retval  None
  * @author  �����
  * @Data    2024-06-06
 **/
/* -------------------------------- end -------------------------------- */
void L76X_Send_Command(char *data)
{
    char Check = data[1], Check_char[3]={0};
    UBYTE i = 0;
    Uart3_SendString((uint8_t *)"\r\n");
    
    //printf(" 1i = %d Check =%x \n", i, Check);
    for(i=2; data[i] != '\0'; i++){
        Check ^= data[i];       //Calculate the check value
    }
    //printf(" i = %d Check =%x \n", i, Check);
    Check_char[0] = Temp[Check/16%16];
    Check_char[1] = Temp[Check%16];
	Check_char[2] = '\0';
   
    Uart3_SendString((uint8_t*)data);
    Uart3_SendString((uint8_t*)"*");
    Uart3_SendString((uint8_t*)Check_char);
	Uart3_SendString((uint8_t *)"\r\n");
}



/* -------------------------------- begin  -------------------------------- */
/**
  * @Name    convertToBeijingTime
  * @brief   ����ʱ��ת������
  * @param   None
  * @retval  None
  * @author  �����
  * @Data    2024-06-06
 **/
/* -------------------------------- end -------------------------------- */
void convertToBeijingTime(int *hours, int *minutes, float *seconds) {
    *hours += 8;  // Beijing is UTC+8

    if (*hours >= 24) {
        *hours -= 24;  // Adjust if hours go beyond 24
    }
}



/* -------------------------------- begin  -------------------------------- */
/**
  * @Name    convertUTCtoHMS
  * @brief   UTCʱ��ת������
  * @param   None
  * @retval  None
  * @author  �����
  * @Data    2024-06-06
 **/
/* -------------------------------- end -------------------------------- */
void convertUTCtoHMS(const char *utc_time, int *hours, int *minutes, float *seconds) {
    // Extract hours
    char hour_str[3] = {utc_time[0], utc_time[1], '\0'};
    *hours = atoi(hour_str);

    // Extract minutes
    char minute_str[3] = {utc_time[2], utc_time[3], '\0'};
    *minutes = atoi(minute_str);

    // Extract seconds
    char second_str[7] = {utc_time[4], utc_time[5], '.', utc_time[7], utc_time[8], utc_time[9], '\0'};
    *seconds = atof(second_str);
}

/* -------------------------------- begin  -------------------------------- */
/**
  * @Name    rtc_set_time
  * @brief   RTCʱ������
  * @param   hour,min,sec: Сʱ,����,����  ampm: AM/PM, 0=AM/24H; 1=PM/12H
  * @retval  0,�ɹ�
  * @author  �����
  * @Data    2024-06-06
 **/
/* -------------------------------- end -------------------------------- */
HAL_StatusTypeDef rtc_set_time(uint8_t hour, uint8_t min, uint8_t sec, uint8_t ampm)
{
    RTC_TimeTypeDef rtc_time_handle;
 
    rtc_time_handle.Hours = hour;
    rtc_time_handle.Minutes = min;
    rtc_time_handle.Seconds = sec;
    rtc_time_handle.TimeFormat = ampm;
    rtc_time_handle.DayLightSaving = RTC_DAYLIGHTSAVING_NONE;
    rtc_time_handle.StoreOperation = RTC_STOREOPERATION_RESET;
    return HAL_RTC_SetTime(&hrtc, &rtc_time_handle, RTC_FORMAT_BIN);
}

/* -------------------------------- begin  -------------------------------- */
/**
  * @Name    rtc_set_date
  * @brief   RTC��������
  * @param   year,month,date : ��(0~99),��(1~12),��(0~31)  week : ����(1~7,0,�Ƿ�!)
  * @retval  0,�ɹ�
  * @author  �����
  * @Data    2024-06-06
 **/
/* -------------------------------- end -------------------------------- */
HAL_StatusTypeDef rtc_set_date(uint8_t year, uint8_t month, uint8_t date)
{
    RTC_DateTypeDef rtc_date_handle;
 
    rtc_date_handle.Date = date;
    rtc_date_handle.Month = month;
    rtc_date_handle.Year = year;
    rtc_date_handle.WeekDay = (date+2*month+3*(month+1)/5+year+year/4-year/100+year/400+1)%7;	//�����������һ������Ȼ������,��ʽ��׼
    return HAL_RTC_SetDate(&hrtc, &rtc_date_handle, RTC_FORMAT_BIN);
}


/* -------------------------------- begin  -------------------------------- */
/**
  * @Name    parseDate
  * @brief   GNSS����ת������
  * @param   year,month,date : ��(0~99),��(1~12),��(0~31)  week : ����(1~7,0,�Ƿ�!)
  * @retval  0,�ɹ�
  * @author  �����
  * @Data    2024-06-06
 **/
/* -------------------------------- end -------------------------------- */
void parseDate(char *dateString, int *day, int *month, int *year)
{
    char dayStr[3] = {dateString[0], dateString[1], '\0'};
    char monthStr[3] = {dateString[2], dateString[3], '\0'};
    char yearStr[3] = {dateString[4], dateString[5], '\0'};

    *day = atoi(dayStr);
    *month = atoi(monthStr);
    *year = atoi(yearStr);
}


// ����γ���ַ�������ʽΪDDMM.MMMMM
double parseLatitude(const char *lat) {
    char degrees[3] = {0};
    char minutes[10] = {0};
    
    // ��ȡ�Ⱥͷ�
    strncpy(degrees, lat, 2);
    strncpy(minutes, lat + 2, 9);

    double latDegrees = atof(degrees);
    double latMinutes = atof(minutes);

    // ת��Ϊʮ���ƶ���ֵ
    return latDegrees + (latMinutes / 60.0);
}

// ���������ַ�������ʽΪDDDMM.MMMMM
double parseLongitude(const char *lon) {
    char degrees[4] = {0};
    char minutes[10] = {0};
    
    // ��ȡ�Ⱥͷ�
    strncpy(degrees, lon, 3);
    strncpy(minutes, lon + 3, 9);

    double lonDegrees = atof(degrees);
    double lonMinutes = atof(minutes);

    // ת��Ϊʮ���ƶ���ֵ
    return lonDegrees + (lonMinutes / 60.0);
}

// ������ת��GPS��γ���ַ���
void parseGPSCoordinates(_GNSS *GPS) {
    GPS->latitude_dou = parseLatitude(GPS->latitude);
    GPS->longitude_dou = parseLongitude(GPS->longitude);

}


